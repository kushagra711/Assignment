package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CharacterRepository extends JpaRepository<Character, Long> {
    List<Character> findByHouse(String house);
    List<Character> findByRoleAndIsFriendIsTrue(String role);
    List<Character> findByIsFamilyIsTrueAndNameContaining(String name);
    List<Character> findByRoleAndIsEnemyIsTrueOrderByHouse(String role);
}
