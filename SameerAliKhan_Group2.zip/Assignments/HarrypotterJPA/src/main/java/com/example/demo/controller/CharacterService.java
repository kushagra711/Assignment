package com.example.demo.controller;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.repo.CharacterRepository;

@Service
public class CharacterService {
    private final CharacterRepository characterRepository;

    @Autowired
    public CharacterService(CharacterRepository characterRepository) {
        this.characterRepository = characterRepository;
    }

    public List<Character> createCharacters(List<Character> characters) {
        return characterRepository.saveAll(characters);
    }

    public List<String> getGryffindorHouseMembers() {
        return characterRepository.findByHouse("Gryffindor")
                                  .stream()
                                  .map(Character::getName)
                                  .collect(Collectors.toList());
    }

    public Map<String, List<Character>> getAliveCharactersGroupedByHouse() {
        List<Character> aliveCharacters = characterRepository.findByRoleAndIsFriendIsTrue("Student");

        return aliveCharacters.stream()
                              .collect(Collectors.groupingBy(Character::getHouse,Collectors.toList()));
    }

    public List<Character> getFamilyMembersOfHarryPotter() {
        return characterRepository.findByIsFamilyIsTrueAndNameContaining("Potter");
    }

    public List<Character> getDeceasedFacultyMembers() {
        return characterRepository.findByRoleAndIsEnemyIsTrueOrderByHouse("Faculty");
    }
}