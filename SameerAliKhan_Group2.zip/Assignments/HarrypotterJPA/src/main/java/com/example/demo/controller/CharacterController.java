package com.example.demo.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/characters")
public class CharacterController {
    private final CharacterService characterService;

    @Autowired
    public CharacterController(CharacterService characterService) {
        this.characterService = characterService;
    }

    @PostMapping("/create")
    public List<Character> createCharacters(@RequestBody List<Character> characters) {
        return characterService.createCharacters(characters);
    }

    @GetMapping("/gryffindor")
    public List<String> getGryffindorHouseMembers() {
        return characterService.getGryffindorHouseMembers();
    }

    @GetMapping("/alive-grouped-by-house")
    public ResponseEntity<Map<String, List<Character>>> getAliveCharactersGroupedByHouse() {
        Map<String, List<Character>> charactersByHouse = characterService.getAliveCharactersGroupedByHouse();
        return ResponseEntity.ok(charactersByHouse);
    }

    @GetMapping("/potter-family")
    public List<Character> getFamilyMembersOfHarryPotter() {
        return characterService.getFamilyMembersOfHarryPotter();
    }

    @GetMapping("/deceased-faculty")
    public List<Character> getDeceasedFacultyMembers() {
        return characterService.getDeceasedFacultyMembers();
    }
}