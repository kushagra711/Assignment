package com.mvcharrypotter.HarrypotterMVCAssign.config;

import org.springframework.stereotype.Component;

@Component
public class Character {
    private String name;
    private String house;
    private String role;
    private String status;
    private String dies;
    
	public Character(String name, String house, String role, String status, String dies) {
		super();
		this.name = name;
		this.house = house;
		this.role = role;
		this.status = status;
		this.dies = dies;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHouse() {
		return house;
	}
	public void setHouse(String house) {
		this.house = house;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDies() {
		return dies;
	}
	public void setDies(String dies) {
		this.dies = dies;
	}
    
}

