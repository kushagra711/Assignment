package com.mvcharrypotter.HarrypotterMVCAssign.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mvcharrypotter.HarrypotterMVCAssign.config.Character;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class CharacterController {
	
    private List<Character> characters = new ArrayList<>();

    @RequestMapping("/students")
    public String getStudents(Model model) {
        List<Character> students = getSampleStudents();
        model.addAttribute("students", students);
        return "student-list";
    }
    
    @RequestMapping("/gryffindor")
    @ResponseBody
    public List<String> getGryffindorCharacters() {
        List<String> gryffindorNames = new ArrayList<>();
        
        for (Character character : characters) {
            if ("Gryffindor".equals(character.getHouse())) {
                gryffindorNames.add(character.getName());
            }
        }
        
        return gryffindorNames;
    }
    
    @RequestMapping("/alive-by-house")
    @ResponseBody
    public Map<String, List<Character>> getAliveCharactersByHouse() {
        Map<String, List<Character>> aliveCharactersByHouse = new HashMap<>();
        
        for (Character character : characters) {
            if (character.getDies()=="No") {
                aliveCharactersByHouse
                    .computeIfAbsent(character.getHouse(), k -> new ArrayList<>())
                    .add(character);
            }
        }
        
        return aliveCharactersByHouse;
    }
    
    @RequestMapping("/harry-potter-family")
    @ResponseBody
    public List<Character> getHarryPotterFamilyMembers() {
        List<Character> harryPotterFamilyMembers = new ArrayList<>();
        
        for (Character character : characters) {
            if ("Family".equals(character.getStatus())) {
                harryPotterFamilyMembers.add(character);
                break; // Assuming there's only one Harry Potter character
            }
        }
        
        return harryPotterFamilyMembers;
    }
    
    @RequestMapping("/faculty-deceased")
    @ResponseBody
    public List<Character> getDeceasedFacultyMembers() {
        List<Character> deceasedFacultyMembers = new ArrayList<>();
        
        for (Character character : characters) {
            if (character.getDies() == "Yes" && "Faculty".equals(character.getRole())) {
                deceasedFacultyMembers.add(character);
            }
        }
        
        // Sort the deceased faculty members alphabetically by name
        Collections.sort(deceasedFacultyMembers, Comparator.comparing(Character::getName));
        
        return deceasedFacultyMembers;
    }
    
    private List<Character> getSampleStudents() {
        characters.add(new Character("Harry Potter", "Gryffindor", "Student", "Self", "No"));
        characters.add(new Character("Ginny Weasley", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Ron Weasley", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Hermione Granger", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Neville Longbottom", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Oliver Wood", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Luna Lovegood", "Ravenclaw", "Student", "Friend", "No"));
        characters.add(new Character("Cho Chang", "Ravenclaw", "Student", "Friend", "No"));
        characters.add(new Character("Cedric Diggory", "Hufflepuff", "Student", "Friend", "Yes"));
        characters.add(new Character("Hannah Abbot", "Hufflepuff", "Student", "Friend", "No"));
        characters.add(new Character("Draco Malfoy", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new Character("Vincent Crabbe", "Slytherin", "Student", "Enemy", "Yes"));
        characters.add(new Character("Gregory Goyle", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new Character("Penelope Clearwater", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new Character("Albus Dumbledore", "Gryffindor", "Faculty", "Friend", "Yes"));
        characters.add(new Character("Severus Snape", "Slytherin", "Faculty", "Enemy", "Yes"));
        characters.add(new Character("Remus Lupin", "Gryffindor", "Faculty", "Friend", "Yes"));
        characters.add(new Character("Horace Slughorn", "Slytherin", "Faculty", "Friend", "No"));
        characters.add(new Character("Rubeus Hagrid", "Gryffindor", "Faculty", "Friend", "No"));
        characters.add(new Character("Minerva McGonagall", "Gryffindor", "Faculty", "Friend", "No"));
        characters.add(new Character("James Potter", "Gryffindor", "Student", "Family", "Yes"));
        characters.add(new Character("Sirius Black", "Gryffindor", "Student", "Friend", "Yes"));
        characters.add(new Character("Lily Potter", "Gryffindor", "Student", "Family", "Yes"));
        characters.add(new Character("Peter Pettigrew", "Gryffindor", "Student", "Enemy", "Yes"));
        characters.add(new Character("Tom Marvolo Riddle", "Slytherin", "Student", "Enemy", "Yes"));

        return characters;
    }
}
