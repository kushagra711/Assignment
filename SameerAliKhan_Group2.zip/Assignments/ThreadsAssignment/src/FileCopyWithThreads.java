import java.io.*;

public class FileCopyWithThreads {
    public static void main(String[] args) {
        String sourceFilePath = "F:\\eclipse-workspace\\ThreadsAssignment\\src\\source.txt";
        String destinationFilePath = "F:\\eclipse-workspace\\ThreadsAssignment\\src\\destination.txt";

        // Creating instances of the source and destination files
        File sourceFile = new File(sourceFilePath);
        File destinationFile = new File(destinationFilePath);

        // Creating instances of the reader and writer streams
        FileReader fileReader = null;
        FileWriter fileWriter = null;

        try {
            fileReader = new FileReader(sourceFile);
            fileWriter = new FileWriter(destinationFile);

            // Creating threads for reading and writing
            Thread readThread = new Thread(new ReadThread(fileReader, fileWriter));
            Thread writeThread = new Thread(new WriteThread(fileWriter));

            // Starting the threads
            readThread.start();
            writeThread.start();

            // Waiting for both threads to finish
            readThread.join();
            writeThread.join();

            System.out.println("File copy completed successfully.");
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        } finally {
            try {
                if (fileReader != null) {
                    fileReader.close();
                }
                if (fileWriter != null) {
                    fileWriter.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

class ReadThread implements Runnable {
    private FileReader fileReader;
    private FileWriter fileWriter;

    public ReadThread(FileReader reader, FileWriter writer) {
        this.fileReader = reader;
        this.fileWriter = writer;
    }

    @Override
    public void run() {
        try (BufferedReader bufferedReader = new BufferedReader(fileReader)) {
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                synchronized (fileWriter) {
                    fileWriter.write(line + "\n");
                    fileWriter.flush();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class WriteThread implements Runnable {
    private FileWriter fileWriter;

    public WriteThread(FileWriter writer) {
        this.fileWriter = writer;
    }

    @Override
    public void run() {
       
    }
}
