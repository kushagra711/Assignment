package com.Harrypotter.JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.sql.DatabaseMetaData;

import java.sql.ResultSetMetaData;

/**
 * Hello world!
 *
 */
public class HarrypotterApp 
{
    public static void main( String[] args ) throws ClassNotFoundException, SQLException
    {
    	// Load the Driver in the Code
    	Class.forName("com.mysql.cj.jdbc.Driver");
    	System.out.println("Loaded Driver");
    	
    	//Step 2: Establish/Obtain the connection with db using getConnection() of DriverManager class	
    	Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","admin");
		System.out.println("Connection Establised");
		
		//Step 3: Create database
		Statement st = c.createStatement();
		String createDatabaseQuery = "CREATE DATABASE IF NOT EXISTS harrypotterdb";
        st.executeUpdate(createDatabaseQuery);
        System.out.println("Database created.");
        
    	Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/harrypotterdb","root","admin");
        //Step 4: Create table
		Statement statement = conn.createStatement();
		String createTableQuery = "CREATE TABLE IF NOT EXISTS harrypotterCharactersList (" +
                "id INT AUTO_INCREMENT PRIMARY KEY," +
                "name VARCHAR(20) NOT NULL," +
                "house VARCHAR(20)," +
                "role VARCHAR(20)," +
                "status VARCHAR(20)," +
                "dies VARCHAR(20)" +
                ")";
        statement.executeUpdate(createTableQuery);
        System.out.println("Table created successfully.");
        
        //Step 5: Insert data
        String[] charactersData = {
                "Harry Potter, Gryffindor, Student, Friend, No",
                "Ginny Weasley, Gryffindor, Student, Friend, No",
                "Ron Weasley, Gryffindor, Student, Friend, No",
                "Hermione Granger, Gryffindor, Student, Friend, No",
                "Neville Longbottom, Gryffindor, Student, Friend, No",
                "Oliver Wood, Gryffindor, Student, Friend, No",
                "Luna Lovegood, Ravenclaw, Student, Friend, No",
                "Cho Chang, Ravenclaw, Student, Friend, No",
                "Cedric Diggory, Hufflepuff, Student, Friend, Yes",
                "Hannah Abbot, Hufflepuff, Student, Friend, No",
                "Draco Malfoy, Slytherin, Student, Enemy, No",
                "Vincent Crabbe, Slytherin, Student, Enemy, Yes",
                "Gregory Goyle, Slytherin, Student, Enemy, No",
                "Penelope Clearwater, Slytherin, Student, Enemy, No",
                "Albus Dumbledore, Gryffindor, Faculty, Friend, Yes",
                "Severus Snape, Slytherin, Faculty, Enemy, Yes",
                "Remus Lupin, Gryffindor, Faculty, Friend, Yes",
                "Horace Slughorn, Slytherin, Faculty, Friend, No",
                "Rubeus Hagrid, Gryffindor, Faculty, Friend, No",
                "Minerva McGonagall, Gryffindor, Faculty, Friend, No",
                "James Potter, Gryffindor, Student, Family, Yes",
                "Sirius Black, Gryffindor, Student, Friend, Yes",
                "Lily Potter, Gryffindor, Student, Family, Yes",
                "Peter Pettigrew, Gryffindor, Student, Enemy, Yes",
                "Tom Marvolo Riddle, Slytherin, Student, Enemy, Yes",
            };
//        String insertQuery = "INSERT INTO harrypotterCharactersList (name, house, role, status, dies) VALUES (?, ?, ?, ?, ?)";
//        PreparedStatement preparedStatement = conn.prepareStatement(insertQuery);
//        
//        for (String characterData : charactersData) {
//            String[] dataParts = characterData.split(", ");
//            preparedStatement.setString(1, dataParts[0]);
//            preparedStatement.setString(2, dataParts[1]);
//            preparedStatement.setString(3, dataParts[2]);
//            preparedStatement.setString(4, dataParts[3]);
//            preparedStatement.setString(5, dataParts[4]);
//            preparedStatement.executeUpdate();
//        }
//        
//        System.out.println("Data inserted successfully.");
		
        String selectQuery = "SELECT * FROM harrypotterCharactersList ORDER BY id ASC";
        ResultSet resultSet = statement.executeQuery(selectQuery);
        
        // Display the data
        System.out.println("ID\tName\t\tHouse\t\tRole\t\tStatus\t\tDies");
        System.out.println("-------------------------------------------------------------------------------");
        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            String name = resultSet.getString("name");
            String house = resultSet.getString("house");
            String role = resultSet.getString("role");
            String status = resultSet.getString("status");
            String dies = resultSet.getString("dies");
            
            System.out.printf("%d\t%s\t%s\t%s\t\t%s\t\t%s%n", id, name, house, role, status, dies);
        }
        System.out.println();
        String q1 = "SELECT name FROM harrypotterCharactersList WHERE house='Gryffindor'";
        ResultSet res1 = statement.executeQuery(q1);
        while(res1.next()) {
        	System.out.println(res1.getString("name"));
        }
        System.out.println();
        String q2 = "SELECT * FROM harrypotterCharactersList WHERE dies='No' GROUP BY house";
        ResultSet res2 = statement.executeQuery(q2);
        while(res2.next()) {
        	int id = res2.getInt("id");
            String name = res2.getString("name");
            String house = res2.getString("house");
            String role = res2.getString("role");
            String status = res2.getString("status");
            String dies = res2.getString("dies");
            
            System.out.printf("%d\t%s\t%s\t%s\t\t%s\t\t%s%n", id, name, house, role, status, dies);
        }
        System.out.println();
        String q3 = "SELECT * FROM harrypotterCharactersList WHERE status='Family'";
        ResultSet res3 = statement.executeQuery(q3);
        while(res3.next()) {
        	int id = res3.getInt("id");
            String name = res3.getString("name");
            String house = res3.getString("house");
            String role = res3.getString("role");
            String status = res3.getString("status");
            String dies = res3.getString("dies");
            
            System.out.printf("%d\t%s\t%s\t%s\t\t%s\t\t%s%n", id, name, house, role, status, dies);
        }
        System.out.println();
        String q4 = "SELECT * FROM harrypotterCharactersList WHERE dies='Yes' AND role='Faculty' ORDER BY name ASC";
        ResultSet res4 = statement.executeQuery(q4);
        while(res4.next()) {
        	int id = res4.getInt("id");
            String name = res4.getString("name");
            String house = res4.getString("house");
            String role = res4.getString("role");
            String status = res4.getString("status");
            String dies = res4.getString("dies");
            
            System.out.printf("%d\t%s\t%s\t%s\t\t%s\t\t%s%n", id, name, house, role, status, dies);
        }
        
		DatabaseMetaData dmd=c.getMetaData();
		
		System.out.println(dmd.getDatabaseMajorVersion());
		System.out.println(dmd.getDatabaseProductVersion());
	}
}