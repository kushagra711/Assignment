package com.demo.JdbcAssign;
import com.demo.JdbcAssign.connections.DbConnection;
import com.demo.JdbcAssign.operations.CreateAndInsetValue;

import java.sql.*;
public class App 
{
    public static void main( String[] args ) throws SQLException, ClassNotFoundException
    {
    	 Class.forName("com.mysql.cj.jdbc.Driver");

         DbConnection dbConnection = new DbConnection();
         System.out.println("connection established");
         CreateAndInsetValue createAndInsetValue = new CreateAndInsetValue();
         createAndInsetValue.totalCountBySinglesLpEp();

         dbConnection.getC().close();
    }
}
