package com.demo.JdbcAssign.connections;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnection {
	 private final Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/beatles","root","Rahul@123");

	    public Connection getC() {
	        return c;
	    }

	    public DbConnection() throws SQLException {
	    }

}
