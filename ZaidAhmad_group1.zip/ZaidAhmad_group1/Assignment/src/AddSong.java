import java.time.LocalDate;

@FunctionalInterface
public interface AddSong {
    void addSong(int year, String type, String title, LocalDate releaseDate);
}
