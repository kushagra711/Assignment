import java.time.LocalDate;
import java.util.Date;

public class Song {
    int year;
    String type;

    public LocalDate getReleaseDate() {
        return releaseDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    String title;

    LocalDate releaseDate;
    public Song(int year, String type,String title,LocalDate releaseDate) {
        this.year=year;
        this.type=type;
        this.title=title;
        this.releaseDate = releaseDate;
    }

}
