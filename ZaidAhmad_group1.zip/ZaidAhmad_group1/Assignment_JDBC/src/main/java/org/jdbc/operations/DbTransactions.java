package org.jdbc.operations;

import java.sql.SQLException;

public interface DbTransactions {
    void createAndInsert() throws SQLException;
    void singlesBeforeThanksGiving() throws SQLException;

    void totalCountBySinglesLpEp() throws SQLException;
}
