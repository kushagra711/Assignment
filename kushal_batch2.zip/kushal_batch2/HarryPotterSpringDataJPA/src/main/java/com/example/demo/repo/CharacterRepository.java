package com.example.demo.repo;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Characterinfo;

import java.util.List;

@Repository
public interface CharacterRepository extends JpaRepository<Characterinfo, String> {
    List<Characterinfo> findByHouse(String house);
    List<Characterinfo> findByStatus(String status);
    List<Characterinfo> findByDies(String dies);
    List<Characterinfo> findByRoleAndDies(String role, String dies);
    
}
