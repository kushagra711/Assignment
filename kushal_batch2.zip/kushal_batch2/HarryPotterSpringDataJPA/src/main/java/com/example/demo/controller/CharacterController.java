package com.example.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Characterinfo;
import com.example.demo.repo.CharacterRepository;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/characters")
public class CharacterController {

    @Autowired
    private CharacterRepository characterRepository;
    //Task 1 - to display all the characters
    @GetMapping("/all")
    public List<Characterinfo> getAllCharacters() {
        return characterRepository.findAll();
    }

    //Task 2 - characters belonging to Gryffindorcharacters
    @GetMapping("/gryffindor")
    public List<Characterinfo> getGryffindorCharacters() {
        return characterRepository.findByHouse("Gryffindor");
    }
    //Task 3 - characters who are alive and grouped by their houses 
 
    @GetMapping("/alive-grouped-by-house")
    public Map<String, List<Characterinfo>> getAliveCharactersGroupedByHouse() {
        List<Characterinfo> aliveCharacters = characterRepository.findByDies("No");
        
        return aliveCharacters.stream()
            .collect(Collectors.groupingBy(Characterinfo::getHouse));
    }
    
    //Task 4 - Display Family members of HarryPotter
    @GetMapping("/harryfamily")
    public List<Characterinfo> getFamilyMembers() {
        return characterRepository.findByStatus("family");
    }


  //Task 5 - Display faculty members who will die and sorted by alphabetically
    @GetMapping("/dying-faculty")
    public List<Characterinfo> getDyingFacultyMembers() {
        List<Characterinfo> dyingFacultyMembers = characterRepository.findByRoleAndDies("Faculty", "Yes");
        dyingFacultyMembers.sort(Comparator.comparing(Characterinfo::getName));
        return dyingFacultyMembers;
    }
}



