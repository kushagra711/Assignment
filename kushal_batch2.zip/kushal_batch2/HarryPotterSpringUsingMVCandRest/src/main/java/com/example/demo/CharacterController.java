package com.example.demo;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/harrylist")
public class CharacterController {

    private static List<Characterinfo> characters = new ArrayList<>();

    static {
        characters.add(new Characterinfo("Harry Potter", "Gryffindor", "Student", "Self", "No"));
        characters.add(new Characterinfo("Ginny Weasley", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Characterinfo("Ron Weasley","Gryffindor","Student","Friend","No"));
        characters.add(new Characterinfo("Ron Weasley", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Characterinfo("Hermione Granger", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Characterinfo("Neville Longbottom", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Characterinfo("Oliver Wood", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Characterinfo("Luna Lovegood", "Ravenclaw", "Student", "Friend", "No"));
        characters.add(new Characterinfo("Cho Chang", "Ravenclaw", "Student", "Friend", "No"));
        characters.add(new Characterinfo("Cedric Diggory", "Hufflepuff", "Student", "Friend", "Yes"));
        characters.add(new Characterinfo("Hannah Abbot", "Hufflepuff", "Student", "Friend", "No"));
        characters.add(new Characterinfo("Draco Malfoy", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new Characterinfo("Vincent Crabbe", "Slytherin", "Student", "Enemy", "Yes"));
        characters.add(new Characterinfo("Gregory Goyle", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new Characterinfo("Penelope Clearwater", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new Characterinfo("Albus Dumbledore", "Gryffindor", "Faculty", "Friend", "Yes"));
        characters.add(new Characterinfo("Severus Snape", "Slytherin", "Faculty", "Enemy", "Yes"));
        characters.add(new Characterinfo("Remus Lupin", "Gryffindor", "Faculty", "Friend", "Yes"));
        characters.add(new Characterinfo("Horace Slughorn", "Slytherin", "Faculty", "Friend", "No"));
        characters.add(new Characterinfo("Rubeus Hagrid", "Gryffindor", "Faculty", "Friend", "No"));
        characters.add(new Characterinfo("Minerva McGonagall", "Gryffindor", "Faculty", "Friend", "No"));
        characters.add(new Characterinfo("James Potter", "Gryffindor", "Student", "Family", "Yes"));
        characters.add(new Characterinfo("Sirius Black", "Gryffindor", "Student", "Friend", "Yes"));
        characters.add(new Characterinfo("Lily Potter", "Gryffindor", "Student", "Family", "Yes"));
        characters.add(new Characterinfo("Peter Pettigrew", "Gryffindor", "Student", "Enemy", "Yes"));
        characters.add(new Characterinfo("Tom Marvolo Riddle", "Slytherin", "Student", "Enemy", "Yes"));
    }

  //Task 1 - to display all the characters
    @GetMapping("/characters")
    public ArrayList<Characterinfo> all() {
        return (ArrayList<Characterinfo>) characters;
    }


    //Task 2 - characters belonging to similar house
    @GetMapping("/getbyhouse/{house}")
    public List<Characterinfo> getCharactersByHouse(@PathVariable String house) {
        return characters.stream()
                .filter(character -> character.getHouse().equalsIgnoreCase(house))
                .collect(Collectors.toList());
    }
    
    //Task 3 - characters who are alive and grouped by their houses 
    @GetMapping("/getalivegroupedbyhouse")
    public Map<String, List<Characterinfo>> aliveGroupedByHouse() {
        return groupByHouse(peopleDies("No"));
    }



    //Task 4 - Display Family members of HarryPotter
    @GetMapping("/harryfamily")
    public List<Characterinfo> getCharactersByStatus() {
        return characters.stream()
                .filter(character -> character.getStatus().equalsIgnoreCase("family"))
                .collect(Collectors.toList());
    }

    //Task 5 - Display faculty members who will die and sorted by alphabetically
    @GetMapping("/facultywhodies")
    public List<Characterinfo> deadFaculty() {
        return filterByDiesAndRole("Yes", "Faculty")
                .stream()
                .sorted(Comparator.comparing(Characterinfo::getName)) // Sort by name
                .collect(Collectors.toList());
    }
    
    private Map<String, List<Characterinfo>> groupByHouse(List<Characterinfo> characters) {
        return characters.stream()
                .collect(Collectors.groupingBy(Characterinfo::getHouse));
    }
    

    private List<Characterinfo> peopleDies(String dies) {
        return characters.stream()
                .filter(character -> character.getDies().equalsIgnoreCase(dies))
                .collect(Collectors.toList());
    }

    private List<Characterinfo> filterByDiesAndRole(String dies, String role) {
        return characters.stream()
                .filter(character -> character.getDies().equalsIgnoreCase(dies))
                .filter(character -> character.getRole().equalsIgnoreCase(role))
                .collect(Collectors.toList());
    }
}

