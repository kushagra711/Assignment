package com.telstra.task.assignment_2;

import java.sql.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class Character {
    String name;
    String house;
    String role;
    String status;
    String dies;

    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHouse() {
		return house;
	}

	public void setHouse(String house) {
		this.house = house;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDies() {
		return dies;
	}

	public void setDies(String dies) {
		this.dies = dies;
	}

	public Character(String name, String house, String role, String status, String dies) {
        this.name = name;
        this.house = house;
        this.role = role;
        this.status = status;
        this.dies = dies;
    }


    @Override
    public String toString() {
        return "Character [name=" + name + ", house=" + house + ", role=" + role + ", status=" + status + ", dies=" + dies + "]";
    }
}

public class HarryPotterCharactersUsingMySQL  {
    public static void main(String[] args) throws Exception {

   	 Class.forName("com.mysql.cj.jdbc.Driver");
     Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/batch2", "root", "admin");
     System.out.println("Connection established to database");

     	//Task 1 - to display all the characters
        List<Character> characters = fetchAndCreateCharactersFromDatabase();

        String insertSql = "insert into harrypotter values (?, ?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(insertSql)) {
            for (Character character : characters) {
                preparedStatement.setString(1, character.name);
                preparedStatement.setString(2, character.house);
                preparedStatement.setString(3, character.role);
                preparedStatement.setString(4, character.status);
                preparedStatement.setString(5, character.dies);
                preparedStatement.executeUpdate();
            }

            System.out.println("Characters successfully inserted into the database.");
        }

        List<String> gryffindorCharacters = getGryffindorCharacterNames(connection);
        System.out.println("\nCharaccters belonging to Gryffindor house:\n");
        gryffindorCharacters.forEach(System.out::println);
        
        Map<String, List<Character>> charactersByHouse = groupCharactersByHouse(connection);
        System.out.println("\nCharacters Grouped by House:\n");
        charactersByHouse.forEach((house, chars) -> {
            System.out.println("\nHouse: " + house);
            chars.forEach(System.out::println);
        });
    
        List<Character> harryFamilyMembers = getFamilyMembersOfHarry(connection);
        System.out.println("\nFamily Members of Harry Potter:\n");
        harryFamilyMembers.forEach(System.out::println);

        List<Character> dyingFacultyMembers = getDyingFacultyMembers(connection);
        System.out.println("\nFaculty members who die and Sorted alphabetically:");
        dyingFacultyMembers.forEach(System.out::println);

    }
    private static List<Character> fetchAndCreateCharactersFromDatabase() {
        List<Character> characters = new ArrayList<>();
        characters.add(new Character("Harry Potter", "Gryffindor", "Student", "Self", "No"));
        characters.add(new Character("Ginny Weasley", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Ron Weasley", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Hermione Granger", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Neville Longbottom", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Oliver Wood", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Luna Lovegood", "Ravenclaw", "Student", "Friend", "No"));
        characters.add(new Character("Cho Chang", "Ravenclaw", "Student", "Friend", "No"));
        characters.add(new Character("Cedric Diggory", "Hufflepuff", "Student", "Friend", "Yes"));
        characters.add(new Character("Hannah Abbot", "Hufflepuff", "Student", "Friend", "No"));
        characters.add(new Character("Draco Malfoy", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new Character("Vincent Crabbe", "Slytherin", "Student", "Enemy", "Yes"));
        characters.add(new Character("Gregory Goyle", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new Character("Penelope Clearwater", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new Character("Albus Dumbledore", "Gryffindor", "Faculty", "Friend", "Yes"));
        characters.add(new Character("Severus Snape", "Slytherin", "Faculty", "Enemy", "Yes"));
        characters.add(new Character("Remus Lupin", "Gryffindor", "Faculty", "Friend", "Yes"));
        characters.add(new Character("Horace Slughorn", "Slytherin", "Faculty", "Friend", "No"));
        characters.add(new Character("Rubeus Hagrid", "Gryffindor", "Faculty", "Friend", "No"));
        characters.add(new Character("Minerva McGonagall", "Gryffindor", "Faculty", "Friend", "No"));
        characters.add(new Character("James Potter", "Gryffindor", "Student", "Family", "Yes"));
        characters.add(new Character("Sirius Black", "Gryffindor", "Student", "Friend", "Yes"));
        characters.add(new Character("Lily Potter", "Gryffindor", "Student", "Family", "Yes"));
        characters.add(new Character("Peter Pettigrew", "Gryffindor", "Student", "Enemy", "Yes"));
        characters.add(new Character("Tom Marvolo Riddle", "Slytherin", "Student", "Enemy", "Yes"));
        return characters;
    }

    //Task 2 - characters belonging to Gryffindorcharacters
    private static List<String> getGryffindorCharacterNames(Connection connection) throws SQLException {
        List<String> gryffindorCharacterNames = new ArrayList<>();
        
        String selectSql = "select name FROM harrypotter where house = 'Gryffindor'";
        
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(selectSql)) {
            
            while (resultSet.next()) {
                String name = resultSet.getString("name");
                gryffindorCharacterNames.add(name);
            }
        }
        
        return gryffindorCharacterNames;
    }
    
    //Task 3 - characters who are alive and grouped by their houses 
    private static Map<String, List<Character>> groupCharactersByHouse(Connection connection) throws SQLException {
        Map<String, List<Character>> charactersByHouse = new HashMap<>();
        
        String selectSql = "Select * from harrypotter where dies = 'No'";
        
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(selectSql)) {
            
            while (resultSet.next()) {
                String name = resultSet.getString("name");
                String house = resultSet.getString("house");
                String role = resultSet.getString("role");
                String status = resultSet.getString("status");
                String dies = resultSet.getString("dies");
                
                Character character = new Character(name, house, role, status, dies);
                charactersByHouse.computeIfAbsent(house, k -> new ArrayList<>()).add(character);
            }
        }
        
        return charactersByHouse;
    }

    //Task 4 - Display Family members of HarryPotter
    private static List<Character> getFamilyMembersOfHarry(Connection connection) throws SQLException {
        List<Character> familyMembersOfHarry = new ArrayList<>();
        
        String selectSql = "select * from harrypotter where status = 'Family'";
        
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(selectSql)) {
            
            while (resultSet.next()) {
                String name = resultSet.getString("name");
                String house = resultSet.getString("house");
                String role = resultSet.getString("role");
                String status = resultSet.getString("status");
                String dies = resultSet.getString("dies");
                
                Character character = new Character(name, house, role, status, dies);
                familyMembersOfHarry.add(character);
            }
        }
        return familyMembersOfHarry;
    }

    //Task 5 - Display faculty members who will die and sorted by alphabetically
    private static List<Character> getDyingFacultyMembers(Connection connection) throws SQLException {
        List<Character> dyingFacultyMembers = new ArrayList<>();
        
        String selectSql = "select * from harrypotter where role = 'Faculty' AND dies = 'Yes'";
        
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(selectSql)) {
            
            while (resultSet.next()) {
                String name = resultSet.getString("name");
                String house = resultSet.getString("house");
                String role = resultSet.getString("role");
                String status = resultSet.getString("status");
                String dies = resultSet.getString("dies");
                
                Character character = new Character(name, house, role, status, dies);
                dyingFacultyMembers.add(character);
            }
        }
        dyingFacultyMembers.sort(Comparator.comparing(Character::getName)); 
        return dyingFacultyMembers;
    }

}