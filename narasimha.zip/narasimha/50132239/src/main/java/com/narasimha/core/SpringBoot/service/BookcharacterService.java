package com.narasimha.core.SpringBoot.service;

import java.util.List;
import java.util.Map;

import com.narasimha.core.SpringBoot.entity.BookCharacter;



public interface BookcharacterService {
	
	
	public List<BookCharacter> getAllCharacters();
	
	
	public BookCharacter createBookCharacter(BookCharacter bookCharacter);

	
public List<BookCharacter> nameOfGriffonderHouse();

	
	
	public List<BookCharacter> detailsOfFamilyMembersOfHarrypotter();
	
	
	public List<BookCharacter> facultyMembersWhoDie();
	
	public Map<String, List<BookCharacter>> charactersAlive();
	
}
