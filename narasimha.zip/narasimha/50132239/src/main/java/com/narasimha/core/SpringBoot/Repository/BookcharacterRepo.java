package com.narasimha.core.SpringBoot.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.narasimha.core.SpringBoot.entity.BookCharacter;

public interface BookcharacterRepo extends JpaRepository<BookCharacter, Long> {

}
