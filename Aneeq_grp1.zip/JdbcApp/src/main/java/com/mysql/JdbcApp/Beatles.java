package com.mysql.JdbcApp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;
import java.sql.ResultSet;


public class Beatles {
	
	//2
	public static void getSinglesBeforeThanksgiving(Connection connection, Statement st) throws SQLException {
	    String query = "SELECT * FROM songs WHERE type = 'Single' AND release_date < '1965-11-26'";
	    ResultSet resultSet = st.executeQuery(query);
	    System.out.println("get list of all singles released before 1965 \n");
	    while (resultSet.next()) {
	        int id = resultSet.getInt("id");
	        int year = resultSet.getInt("year");
	        String type = resultSet.getString("type");
	        String title = resultSet.getString("title");
	        Date releaseDate = resultSet.getDate("release_date");
	        
	        
	        // Process and display the retrieved data as needed
	        System.out.println("ID: " + id + ", Year: " + year + ", Type: " + type +
	                ", Title: " + title + ", Release Date: " + releaseDate);
	    }
	}
	
	//3
	public static void getSinglesAndLPsSorted(Connection connection, Statement st) throws SQLException {
	    String query = "SELECT * FROM songs WHERE type IN ('Single', 'LP') ORDER BY release_date";
	    ResultSet resultSet = st.executeQuery(query);
	    System.out.println("Get items that are both singles and LPs and sort them chronologically \n");
	    while (resultSet.next()) {
	        int id = resultSet.getInt("id");
	        int year = resultSet.getInt("year");
	        String type = resultSet.getString("type");
	        String title = resultSet.getString("title");
	        Date releaseDate = resultSet.getDate("release_date");
	        
	        
	        // Process and display the retrieved data as needed
	        System.out.println("ID: " + id + ", Year: " + year + ", Type: " + type +
	                ", Title: " + title + ", Release Date: " + releaseDate);
	    }
	}

	
	//4
	public static void getTotalCounts(Connection connection, Statement st) throws SQLException {
	    String query = "SELECT type, COUNT(*) AS count FROM songs GROUP BY type";
	    ResultSet resultSet = st.executeQuery(query);
	    System.out.println("Get Total Number of Singles, EPs, and LPs Created by the Beatles \n");
	    while (resultSet.next()) {
	        String type = resultSet.getString("type");
	        int count = resultSet.getInt("count");

	        // Process and display the retrieved data as needed
	        System.out.println("Type: " + type + ", Count: " + count);
	    }
	}

	
	//5
	public static void getCountsPerYear(Connection connection, Statement st) throws SQLException {
	    String query = "SELECT year, type, COUNT(*) AS count FROM songs GROUP BY year, type";
	    ResultSet resultSet = st.executeQuery(query);
	    System.out.println("Get Counts of Singles, EPs, and LPs Created by the Beatles per Year \n");
	    while (resultSet.next()) {
	        int year = resultSet.getInt("year");
	        String type = resultSet.getString("type");
	        int count = resultSet.getInt("count");

	        // Process and display the retrieved data as needed
	        System.out.println("Year: " + year + ", Type: " + type + ", Count: " + count);
	    }
	}

	






	
    public static void main(String[] args) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/beatles";
        String username = "root";
        String password = "aneeq1102";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
             Statement st = connection.createStatement()) {
           
        	
        	createTable(connection,st);
        	
        	
        	getSinglesBeforeThanksgiving(connection, st);
            getTotalCounts(connection, st);
            getCountsPerYear(connection, st);
            getSinglesAndLPsSorted(connection, st);
            
            
            
            connection.close();
            st.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
      
    }

	@SuppressWarnings("unused")
	public static void createTable(Connection connection, Statement st) throws SQLException {
		// TODO Auto-generated method stub
		
//		Your CREATE TABLE statement
        String createTableSQL = "CREATE TABLE songs (id INT, year INT, type VARCHAR(255), title VARCHAR(255), release_date DATE)";
        st.executeUpdate(createTableSQL);
        
		// Your INSERT statements
        String[] insertStatements = {
            "INSERT INTO songs (year, type, title, release_date) VALUES (1962, 'Single', 'Love Me Do / P.S. I Love You', '1962-10-05')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1963, 'LP', 'Please Please Me', '1963-03-22')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1963, 'Single', 'From Me To You / Thank You Girl', '1963-04-11')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1963, 'Single', 'She Loves You / I\\'ll Get You', '1963-08-23')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1963, 'LP', 'With The Beatles', '1963-11-22')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1963, 'Single', 'Want To Hold Your Hand / This Boy', '1963-11-29')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1964, 'Single', 'Can\\'t Buy Me Love / You Can\\'t Do That', '1964-03-20')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1964, 'EP', 'Long Tall Sally / I Call Your Name / Slow Down / Matchbox', '1964-04-10')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1964, 'LP', 'A Hard Day\\'s Night', '1964-07-10')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1964, 'Single', 'I Feel Fine / She\\'s A Woman', '1964-11-27')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1964, 'LP', 'Beatles For Sale', '1964-12-04')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1965, 'Single', 'Ticket To Ride / Yes It Is', '1965-04-09')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1965, 'Single', 'Help! / I\\'m Down', '1965-07-23')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1965, 'LP', 'Help!', '1965-08-06')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1965, 'Single', 'We Can Work It Out / Day Tripper', '1965-12-03')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1965, 'LP', 'Rubber Soul', '1965-12-03')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1966, 'Single', 'Paperback Writer / Rain', '1966-06-10')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1966, 'LP', 'Revolver', '1966-08-05')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1966, 'Single', 'Yellow Submarine / Eleanor Rigby', '1966-08-05')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1966, 'Single', 'Strawberry Fields Forever / Penny Lane', '1967-02-13')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1967, 'LP', 'Sgt. Pepper\\'s Lonely Hearts Club Band', '1967-06-01')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1967, 'Single', 'All You Need Is Love / Baby You\\'re A Rich Man', '1967-07-07')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1967, 'Single', 'Hello Goodbye / I Am The Walrus', '1967-11-24')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1967, 'EP', 'Magical Mystery Tour', '1967-11-27')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1967, 'Single', 'Lady Madonna / The Inner Light', '1968-03-15')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1968, 'Single', 'Hey Jude / Revolution', '1968-08-30')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1968, 'LP', 'The Beatles (aka The White Album)', '1968-11-22')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1966, 'LP', 'Yellow Submarine ', '1969-01-17')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1968, 'Single', 'Get Back / Don\\'t Let Me Down', '1969-04-11')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1969, 'Single', 'The Ballad of John and Yoko / Old Brown Shoe', '1969-05-30')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1969, 'LP', 'Abbey Road', '1969-09-26')",
            
            
            
         
            "INSERT INTO songs (year, type, title, release_date) VALUES (1970, 'Single', 'Let It Be / You Know My Name (Look Up The Number)', '1970-03-06')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1970, 'Single', 'The Long and Winding Road / For You Blue', '1970-05-11')",
            "INSERT INTO songs (year, type, title, release_date) VALUES (1970, 'LP', 'Let It Be', '1970-05-18')"
        };
        
     // Execute each INSERT statement
        for (String insertStatement : insertStatements) {
            st.executeUpdate(insertStatement);
        }
	}
}