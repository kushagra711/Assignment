package com.demopackage.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demopackage.demo.model.HPCharacter;
import com.demopackage.demo.model.HPService;




@RestController
@RequestMapping("/hp")
public class HPController {
	
	@Autowired
	HPService hps;
	
	@GetMapping("/allchar")
	public List<HPCharacter> all()
	{
		return hps.allservice();
	}
	
	@GetMapping("/getchar/{name}")
	public HPCharacter onechar(@PathVariable String name)
	{
		return hps.onecharservice(name);
	}
	
	@GetMapping("/getgryffindor")
	public List<HPCharacter> gryff()
	{
		return hps.gryffservice();
	}
	
	@GetMapping("/getalive")
	public List<HPCharacter> alive()
	{
		return hps.aliveservice();
	}
	
	@GetMapping("/getfamily")
	public List<HPCharacter> family()
	{
		return hps.familyservice();
	}
	
	@GetMapping("/getdeadfaculty")
	public List<HPCharacter> deadfaculty()
	{
		return hps.deadfacultyservice();
	}
	
	@PostMapping("/newchar")
	public String addchar(@RequestBody HPCharacter newhpcharacter)
	{
		return hps.addcharservice(newhpcharacter);
	}
	
	@DeleteMapping("/deletechar/{housename}")
	public String delete(@PathVariable String housename)
	{
		return hps.deleteservice(housename);
	
	}
	
	@PutMapping("/updatechar/{pos}")
	public String update(@PathVariable int pos, @RequestBody HPCharacter updatedcharacter)
	{
		return hps.updateservice(pos,updatedcharacter);
	}
	
}
