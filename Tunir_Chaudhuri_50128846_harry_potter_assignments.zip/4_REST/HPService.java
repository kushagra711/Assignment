package com.demopackage.demo.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

@Service
public class HPService {

 List<HPCharacter> list1=Arrays.asList(new HPCharacter("Harry Potter","Gryffindor","Student","Self","No"),new HPCharacter("Ginny Weasley","Gryffindor","Student","Friend","No"),new HPCharacter("Ron Weasley","Gryffindor","Student","Friend","No"),new HPCharacter("Hermione Granger","Gryffindor","Student","Friend","No"),new HPCharacter("Neville Longbottom ","Gryffindor","Student","Friend","No"),new HPCharacter("Oliver Wood","Gryffindor","Student","Friend","No"),new HPCharacter("Luna Lovegood","Ravenclaw","Student","Friend","No"),new HPCharacter("Cho Chang","Ravenclaw","Student","Friend","No"),new HPCharacter("Cedric Diggory","Hufflepuff","Student","Friend","Yes"),new HPCharacter("Hannah Abbot","Hufflepuff","Student","Friend","No"),new HPCharacter("Draco Malfoy","Slytherin","Student","Enemy","No"),new HPCharacter("Vincent Crabbe","Slytherin","Student","Enemy","Yes"),new HPCharacter("Gregory Goyle","Slytherin","Student","Enemy","No"),new HPCharacter("Penelope Clearwater","Slytherin","Student","Enemy","No"),new HPCharacter("Albus Dumbledore","Gryffindor","Faculty","Friend","Yes"),new HPCharacter("Severus Snape","Slytherin","Faculty","Enemy","Yes"),new HPCharacter("Remus Lupin ","Gryffindor","Faculty","Friend","Yes"),new HPCharacter("Horace Slughorn ","Slytherin","Faculty","Friend","No"),new HPCharacter("Rubeus Hagrid","Gryffindor","Faculty","Friend","No"),new HPCharacter("Minerva McGonagall","Gryffindor","Faculty","Friend","No"),new HPCharacter("James Potter","Gryffindor","Student","Family","Yes"),new HPCharacter("Sirius Black","Gryffindor","Student","Friend","Yes"),new HPCharacter("Lily Potter","Gryffindor","Student","Family","Yes"),new HPCharacter("Peter Pettigrew","Gryffindor","Student","Enemy","Yes"),new HPCharacter("Tom Marvolo Riddle","Slytherin","Student","Enemy","Yes"));
 List<HPCharacter> list=new ArrayList<HPCharacter>();
 HPService()
 {
	 list.addAll(list1);
 }
 public List<HPCharacter> allservice()
 {
	 return list;
 }
 public HPCharacter onecharservice(String name)
	{	
		List<HPCharacter> onelist;
		onelist=(ArrayList<HPCharacter>)list.stream().filter(x->x.getName().equalsIgnoreCase(name)).collect(Collectors.toList());
	    return onelist.get(0);
	}
 public List<HPCharacter> gryffservice()
	{
	    return list.stream().filter(x->x.getHouse().equalsIgnoreCase("Gryffindor")).collect(Collectors.toList());
	}
 public List<HPCharacter> aliveservice()
	{
	    ArrayList<HPCharacter> alivelist;
		alivelist=(ArrayList<HPCharacter>) list.stream().filter(x->x.getDies().equalsIgnoreCase("No")).collect(Collectors.toList());
		Collections.sort(alivelist, (p1,p2)->p1.getHouse().compareTo(p2.getHouse()));
		return alivelist;
	}
 public List<HPCharacter> familyservice()
	{
		return list.stream().filter(x->x.getStatus().equalsIgnoreCase("Family")).collect(Collectors.toList());
	}
 public List<HPCharacter> deadfacultyservice()
	{
	    ArrayList<HPCharacter> deathlist;
		deathlist=(ArrayList<HPCharacter>) list.stream().filter(x->x.getDies().equalsIgnoreCase("Yes")).collect(Collectors.toList());
		ArrayList<HPCharacter> deathlistfaculty;
		deathlistfaculty=(ArrayList<HPCharacter>) deathlist.stream().filter(x->x.getRole().equalsIgnoreCase("Faculty")).collect(Collectors.toList());
		Collections.sort(deathlistfaculty, (p1,p2)->p1.getName().compareTo(p2.getName()));
		return deathlistfaculty;
	}
 public String addcharservice(HPCharacter newhpcharacter)
    {
	    list.add(newhpcharacter);
	    return "Character added";
    }
 public String deleteservice(String housename)
 {
	    ArrayList<HPCharacter> deletelist;
	    deletelist=(ArrayList<HPCharacter>)list.stream().filter(x->x.getHouse().equalsIgnoreCase(housename)).collect(Collectors.toList());
	    list.removeAll(deletelist);
	    return "Characters deleted";
 }
 public String updateservice(int pos, HPCharacter updatedcharacter)
 {
	 list.set(pos, updatedcharacter);
	 return "Character updated";
 }
}
