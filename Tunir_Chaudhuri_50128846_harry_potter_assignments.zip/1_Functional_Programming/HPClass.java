package com.telstra.javademo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import com.telstra.javademoentities.HPCharacter;

public class HPClass {

	static ArrayList<HPCharacter> list=new ArrayList<HPCharacter>();
	
	public static void add()
	{
		Supplier<HPCharacter> sup=()->new HPCharacter("Harry Potter","Gryffindor","Student","Self","No");
		list.add(sup.get());
		sup=()->new HPCharacter("Ginny Weasley","Gryffindor","Student","Friend","No");
		list.add(sup.get());
		sup=()->new HPCharacter("Ron Weasley","Gryffindor","Student","Friend","No");
		list.add(sup.get());
		sup=()->new HPCharacter("Hermione Granger","Gryffindor","Student","Friend","No");
		list.add(sup.get());
		sup=()->new HPCharacter("Neville Longbottom ","Gryffindor","Student","Friend","No");
		list.add(sup.get());
		sup=()->new HPCharacter("Oliver Wood","Gryffindor","Student","Friend","No");
		list.add(sup.get());
		sup=()->new HPCharacter("Luna Lovegood","Ravenclaw","Student","Friend","No");
		list.add(sup.get());
		sup=()->new HPCharacter("Cho Chang","Ravenclaw","Student","Friend","No");
		list.add(sup.get());
		sup=()->new HPCharacter("Cedric Diggory","Hufflepuff","Student","Friend","Yes");
		list.add(sup.get());
		sup=()->new HPCharacter("Hannah Abbot","Hufflepuff","Student","Friend","No");
		list.add(sup.get());
		sup=()->new HPCharacter("Draco Malfoy","Slytherin","Student","Enemy","No");
		list.add(sup.get());
		sup=()->new HPCharacter("Vincent Crabbe","Slytherin","Student","Enemy","Yes");
		list.add(sup.get());
		sup=()->new HPCharacter("Gregory Goyle","Slytherin","Student","Enemy","No");
		list.add(sup.get());
		sup=()->new HPCharacter("Penelope Clearwater","Slytherin","Student","Enemy","No");
		list.add(sup.get());
		sup=()->new HPCharacter("Albus Dumbledore","Gryffindor","Faculty","Friend","Yes");
		list.add(sup.get());
		sup=()->new HPCharacter("Severus Snape","Slytherin","Faculty","Enemy","Yes");
		list.add(sup.get());
		sup=()->new HPCharacter("Remus Lupin ","Gryffindor","Faculty","Friend","Yes");
		list.add(sup.get());
		sup=()->new HPCharacter("Horace Slughorn ","Slytherin","Faculty","Friend","No");
		list.add(sup.get());
		sup=()->new HPCharacter("Rubeus Hagrid","Gryffindor","Faculty","Friend","No");
		list.add(sup.get());
		sup=()->new HPCharacter("Minerva McGonagall","Gryffindor","Faculty","Friend","No");
		list.add(sup.get());
		sup=()->new HPCharacter("James Potter","Gryffindor","Student","Family","Yes");
		list.add(sup.get());
		sup=()->new HPCharacter("Sirius Black","Gryffindor","Student","Friend","Yes");
		list.add(sup.get());
		sup=()->new HPCharacter("Lily Potter","Gryffindor","Student","Family","Yes");
		list.add(sup.get());
		sup=()->new HPCharacter("Peter Pettigrew","Gryffindor","Student","Enemy","Yes");
		list.add(sup.get());
		sup=()->new HPCharacter("Tom Marvolo Riddle","Slytherin","Student","Enemy","Yes");
		list.add(sup.get());	
	}
	
	public static void displayGryffindor()
	{
		list.stream().filter(x->x.getHouse().equalsIgnoreCase("Gryffindor")).forEach(x->System.out.println("Welcome to Gryffindor, "+x.getName()));
	}
	
	public static void displayAlive()
	{
		ArrayList<HPCharacter> alivelist;
		alivelist=(ArrayList<HPCharacter>) list.stream().filter(x->x.getDies().equalsIgnoreCase("No")).collect(Collectors.toList());
		Collections.sort(alivelist, (p1,p2)->p1.getHouse().compareTo(p2.getHouse()));
		alivelist.forEach(i->System.out.println(i.getName()+" from House "+i.getHouse()+" is alive"));
	}
	public static void displayFamily()
	{
		list.stream().filter(x->x.getStatus().equalsIgnoreCase("Family")).forEach(x->System.out.println(x.getName()+" is in Harry Potter's family"));
	}
	
	public static void displayDeadFaculty()
	{
		ArrayList<HPCharacter> deathlist;
		deathlist=(ArrayList<HPCharacter>) list.stream().filter(x->x.getDies().equalsIgnoreCase("Yes")).collect(Collectors.toList());
		ArrayList<HPCharacter> deathlistfaculty;
		deathlistfaculty=(ArrayList<HPCharacter>) deathlist.stream().filter(x->x.getRole().equalsIgnoreCase("Faculty")).collect(Collectors.toList());
		Collections.sort(deathlistfaculty, (p1,p2)->p1.getName().compareTo(p2.getName()));
		deathlistfaculty.forEach(i->System.out.println(i.getName()+" is dead"));
	}
	
	public static void main(String args[])
	{
		System.out.println("Let us add everyone");
		add();
		System.out.println("Let us see who goes to Gryffindor");
		displayGryffindor();
		System.out.println("Let us see who are alive");
		displayAlive();
		System.out.println("Let us see the family members of Harry Potter");
		displayFamily();
		System.out.println("Let us see who are the dead teachers");
		displayDeadFaculty();
		
	}
}
