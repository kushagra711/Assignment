package com.GroupDemo.com.ArtifactDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class HPApp {
	
	public static void main( String[] args ) throws ClassNotFoundException, SQLException
    {
    	Class.forName("com.mysql.cj.jdbc.Driver");
    	System.out.println("Loaded Driver");
    	Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/hpdatabase","root","root");
        System.out.println("Connection Establised");
     
        Statement st=c.createStatement();
        st.executeUpdate("delete from hptable");  
        st.executeUpdate("insert into hptable values('Harry Potter','Gryffindor','Student','Self','No')");  
        st.executeUpdate("insert into hptable values('Ginny Weasley','Gryffindor','Student','Friend','No')");
        st.executeUpdate("insert into hptable values('Ron Weasley','Gryffindor','Student','Friend','No')");
        st.executeUpdate("insert into hptable values('Hermoine Granger','Gryffindor','Student','Friend','No')");
        st.executeUpdate("insert into hptable values('Neville Longbottom','Gryffindor','Student','Friend','No')");
        st.executeUpdate("insert into hptable values('Oliver Wood','Gryffindor','Student','Friend','No')");
        st.executeUpdate("insert into hptable values('Luna Lovegood','Ravenclaw','Student','Friend','No')");
        st.executeUpdate("insert into hptable values('Cho Chang','Ravenclaw','Student','Friend','No')");
        st.executeUpdate("insert into hptable values('Cedric Diggory','Hufflepuff','Student','Friend','Yes')");
        st.executeUpdate("insert into hptable values('Hannah Abbot','Hufflepuff','Student','Friend','No')");
        st.executeUpdate("insert into hptable values('Draco Malfoy','Slytherin','Student','Enemy','No')");
        st.executeUpdate("insert into hptable values('Vincent Crabbe','Slytherin','Student','Enemy','Yes')");
        st.executeUpdate("insert into hptable values('Gregory Goyle','Slytherin','Student','Enemy','No')");
        st.executeUpdate("insert into hptable values('Penelope Clearwater','Slytherin','Student','Enemy','No')");
        st.executeUpdate("insert into hptable values('Albus Dumbledore','Gryffindor','Faculty','Friend','Yes')");
        st.executeUpdate("insert into hptable values('Severus Snape','Slytherin','Faculty','Enemy','Yes')");
        st.executeUpdate("insert into hptable values('Remus Lupin','Gryffindor','Faculty','Friend','Yes')");
        st.executeUpdate("insert into hptable values('Horace Slughorn','Slytherin','Faculty','Friend','No')");
        st.executeUpdate("insert into hptable values('Rubeus Hagrid','Gryffindor','Faculty','Friend','No')");
        st.executeUpdate("insert into hptable values('Minerva McGonagall ','Gryffindor','Faculty','Friend','No')");
        st.executeUpdate("insert into hptable values('James Potter','Gryffindor','Student','Family','Yes')");
        st.executeUpdate("insert into hptable values('Sirius Black','Gryffindor','Student','Friend','Yes')");
        st.executeUpdate("insert into hptable values('Lily Potter','Gryffindor','Student','Family','Yes')");
        st.executeUpdate("insert into hptable values('Peter Pettigrew','Gryffindor','Student','Enemy','Yes')");
        st.executeUpdate("insert into hptable values('Tom Marvolo Riddle','Slytherin','Student','Enemy','Yes')");

        ResultSet res=st.executeQuery("select * from hptable where house='Gryffindor'"); 
        while(res.next())
        {
            System.out.println("Welcome to Gryffindor "+res.getString(1));
        }

        res=st.executeQuery("select * from hptable where dies='No' group by house"); 
        while(res.next())
        {
            System.out.println("You are alive "+res.getString(1));
        }
 
        res=st.executeQuery("select * from hptable where status='Family'"); 
        while(res.next())
        {
            System.out.println("Family member "+res.getString(1));
        }

        res=st.executeQuery("select * from hptable where dies='Yes' and role='Faculty' order by name"); 
        while(res.next())
        {
            System.out.println("Rest in peace "+res.getString(1));
        }
        
        res.close();
        st.close();
        c.close();

     }

}
