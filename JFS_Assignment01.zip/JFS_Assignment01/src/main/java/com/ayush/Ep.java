package com.ayush;

import java.util.Date;

public class Ep extends Beatles{
    public Ep(int year, String name, Date date) {
        super(year, name, date);
    }
}
