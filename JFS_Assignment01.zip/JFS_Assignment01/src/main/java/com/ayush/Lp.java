package com.ayush;

import java.util.Date;

public class Lp extends Beatles{
    public Lp(int year, String name, Date date) {
        super(year, name, date);
    }
}
