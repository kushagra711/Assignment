
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Main {


    public static void main(String[] args) {
        ArrayList<Song> table = new ArrayList<>();

        AddSong songsAdder = (year, type, title, releaseDate) -> {
            table.add(new Song(year, type, title, releaseDate));

        };
        //1
        addingSong(songsAdder);
        //2
        singleList(table);
        //3
        List<Song> s=getSinglesAndLPsSorted(table);
        System.out.println();
        System.out.println("Singles and LPs sorted\n");
        for(Song s1: s){
            System.out.println(s1.year+" "+s1.title+" "+s1.releaseDate);
        }
        //4
        countOfSongs(table);

        //5
        System.out.println();
        Map<LocalDate, Map<String, Long>> songsPerYear = countSongTypesPerYear(table);
        System.out.println("Number of Singles, LPs, and EPs created by the Beatles per year:");
        for (Map.Entry<LocalDate, Map<String, Long>> entry : songsPerYear.entrySet()) {
            LocalDate year = entry.getKey();
            Map<String, Long> songTypeCounts = entry.getValue();

            System.out.println("Year: " + year.getYear());
            System.out.println("Singles: " + songTypeCounts.getOrDefault("Single", 0L));
            System.out.println("LPs: " + songTypeCounts.getOrDefault("LP", 0L));
            System.out.println("EPs: " + songTypeCounts.getOrDefault("EP", 0L));
            System.out.println();
        }





    }

    public static Map<LocalDate, Map<String, Long>> countSongTypesPerYear(ArrayList<Song> table) {
        return table.stream()
                .collect(Collectors.groupingBy(song -> song.getReleaseDate().withDayOfYear(1),
                        Collectors.groupingBy(song -> song.getType(), Collectors.counting())));
    }



    public static List<Song> getSinglesAndLPsSorted(ArrayList<Song> table){


        return table.stream()
                .filter(song->song.type.equals("Single")|| song.type.equals("LP"))
                .sorted(Comparator.comparing(song -> song.releaseDate))
                .collect(Collectors.toList());

    }



    public static void singleList(ArrayList<Song> table){
        System.out.println("Single Songs Before Thanksgiving 1965:");
        LocalDate thanksGiving = LocalDate.of(1965,11,25);
       table.stream()
               .filter(song->song.type.equals("Single"))
               .filter(song->song.releaseDate.isBefore(thanksGiving))
               .forEach(song ->
                       System.out.println(song.year+" "+song.title+" "+song.releaseDate));




    }

    public static void countOfSongs(ArrayList<Song> table){
        System.out.println("");

        long count1=table.stream().filter(song->song.type.equals("Single")).count();
        long count2= table.stream().filter(song->song.type.equals("LP")).count();
        long count3=table.stream().filter(song->song.type.equals("EP")).count();

        System.out.println("Number of Singles: " + count1);
        System.out.println("Number of EPs: " + count2);
        System.out.println("Number of LPs: " + count3);
    }

    public static void addingSong(AddSong songsAdder) {
        songsAdder.addSong(1962, "Single", "Love Me Do / P.S. I Love You", LocalDate.of(1962, 10, 5));
        songsAdder.addSong(1963, "LP", "Please Please Me", LocalDate.of(1963, 3, 22));
        songsAdder.addSong(1963, "Single", "From Me To You / Thank You Girl", LocalDate.of(1963, 4, 11));
        songsAdder.addSong(1963, "Single", "She Loves You / I'll Get You", LocalDate.of(1963, 8, 23));
        songsAdder.addSong(1963, "LP", "With The Beatles", LocalDate.of(1963, 11, 22));
        songsAdder.addSong(1963, "Single", "Want To Hold Your Hand / This Boy", LocalDate.of(1963, 11, 29));
        songsAdder.addSong(1964, "Single", "Can't Buy Me Love / You Can't Do That", LocalDate.of(1964, 3, 20));
        songsAdder.addSong(1964, "EP", "Long Tall Sally / I Call Your Name / Slow Down / Matchbox", LocalDate.of(1964, 4, 10));
        songsAdder.addSong(1964, "LP", "A Hard Day's Night", LocalDate.of(1964, 7, 10));
        songsAdder.addSong(1964, "Single", "I Feel Fine / She's A Woman", LocalDate.of(1964, 11, 27));
        songsAdder.addSong(1964, "LP", "Beatles For Sale", LocalDate.of(1964, 12, 4));
        songsAdder.addSong(1965, "Single", "Ticket To Ride / Yes It Is", LocalDate.of(1965, 4, 9));
        songsAdder.addSong(1965, "Single", "Help! / I'm Down", LocalDate.of(1965, 7, 23));
        songsAdder.addSong(1965, "LP", "Help!", LocalDate.of(1965, 8, 6));
        songsAdder.addSong(1965, "Single", "We Can Work It Out / Day Tripper", LocalDate.of(1965, 12, 3));
        songsAdder.addSong(1965, "LP", "Rubber Soul", LocalDate.of(1965, 12, 3));
        songsAdder.addSong(1966, "Single", "Paperback Writer / Rain", LocalDate.of(1966, 6, 10));
        songsAdder.addSong(1966, "LP", "Revolver", LocalDate.of(1966, 8, 5));
        songsAdder.addSong(1966, "Single", "Yellow Submarine / Eleanor Rigby", LocalDate.of(1966, 8, 5));
        songsAdder.addSong(1966, "Single", "Strawberry Fields Forever / Penny Lane", LocalDate.of(1967, 2, 13));
        songsAdder.addSong(1967, "LP", "Sgt. Pepper's Lonely Hearts Club Band", LocalDate.of(1967, 6, 1));
        songsAdder.addSong(1967, "Single", "All You Need Is Love / Baby You're A Rich Man", LocalDate.of(1967, 7, 7));
        songsAdder.addSong(1967, "Single", "Hello Goodbye / I Am The Walrus", LocalDate.of(1967, 11, 24));
        songsAdder.addSong(1967, "EP", "Magical Mystery Tour", LocalDate.of(1967, 11, 27));
        songsAdder.addSong(1967, "Single", "Lady Madonna / The Inner Light", LocalDate.of(1968, 3, 15));
        songsAdder.addSong(1968, "Single", "Hey Jude / Revolution", LocalDate.of(1968, 8, 30));
        songsAdder.addSong(1968, "LP", "The Beatles (aka The White Album)", LocalDate.of(1968, 11, 22));
        songsAdder.addSong(1968, "Single", "Ob-La-Di, Ob-La-Da / While My Guitar Gently Weeps", LocalDate.of(1968, 11, 27));
        songsAdder.addSong(1968, "Single", "Get Back / Don't Let Me Down", LocalDate.of(1969, 4, 11));
        songsAdder.addSong(1969, "Single", "The Ballad of John and Yoko / Old Brown Shoe", LocalDate.of(1969, 5, 30));
        songsAdder.addSong(1969, "LP", "Abbey Road", LocalDate.of(1969, 9, 26));
        songsAdder.addSong(1969, "Single", "Something / Come Together", LocalDate.of(1969, 10, 31));
        songsAdder.addSong(1970, "Single", "Let It Be / You Know My Name (Look Up The Number)", LocalDate.of(1970, 3, 6));
        songsAdder.addSong(1970, "Single", "The Long and Winding Road / For You Blue", LocalDate.of(1970, 5, 11));
        songsAdder.addSong(1970, "LP", "Let It Be", LocalDate.of(1970, 5, 18));
    }

}