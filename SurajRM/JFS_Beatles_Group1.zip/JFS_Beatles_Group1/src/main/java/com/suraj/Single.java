package com.suraj;

import java.util.Date;

public class Single extends Beatles {

    public Single(int year, String name, Date date) {
        super(year, name, date);
    }
}

