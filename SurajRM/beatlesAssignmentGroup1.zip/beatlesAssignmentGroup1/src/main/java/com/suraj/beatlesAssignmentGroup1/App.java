package com.suraj.beatlesAssignmentGroup1;

import java.sql.SQLException;

import com.suraj.connection.DbConnection;
import com.suraj.operations.DbOperations;

public class App 
{
    public static void main( String[] args ) throws ClassNotFoundException, SQLException
    {
    	Class.forName("com.mysql.cj.jdbc.Driver");

        DbConnection dbConnection = new DbConnection();
        System.out.println("connection established");
        DbOperations createAndInsetValue = new DbOperations();
        createAndInsetValue.totalCountBySinglesLpEp();

        dbConnection.getC().close();
    }
}
