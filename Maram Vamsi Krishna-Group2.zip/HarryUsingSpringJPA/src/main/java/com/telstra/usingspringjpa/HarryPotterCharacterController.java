package com.telstra.usingspringjpa;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/characters")
public class HarryPotterCharacterController {
	private HarryPotterCharacterService characterService;
	
	@Autowired
	public HarryPotterCharacterController(HarryPotterCharacterService characterService) {
		this.characterService=characterService;
	}
	
	@GetMapping
	public List<HarryPotterCharacter> getAllCharacters(){
		return characterService.getAllCharacters();
	}
	
	@GetMapping("/{name}")
	public ResponseEntity<HarryPotterCharacter> getChaarcterById(@PathVariable String name){
		Optional<HarryPotterCharacter> character=characterService.getCharacterByName(name);
		return character.map(value->new ResponseEntity<>(value,HttpStatus.OK))
				.orElseGet(()->new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}
	
	@PostMapping("/insert")
    public ResponseEntity<HarryPotterCharacter> createCharacter(@RequestBody HarryPotterCharacter character) {
        HarryPotterCharacter createdCharacter = characterService.createCharacter(character);
        return new ResponseEntity<>(createdCharacter, HttpStatus.CREATED);
    }

    @PutMapping("/{name}")
    public ResponseEntity<HarryPotterCharacter> updateCharacter(@PathVariable String name,
                                                                @RequestBody HarryPotterCharacter character) {
        HarryPotterCharacter updatedCharacter = characterService.updateCharacter(name, character);
        return updatedCharacter != null
                ? new ResponseEntity<>(updatedCharacter, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/{name}")
    public ResponseEntity<Void> deleteCharacter(@PathVariable String name) {
        characterService.deleteCharacter(name);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
	
}
