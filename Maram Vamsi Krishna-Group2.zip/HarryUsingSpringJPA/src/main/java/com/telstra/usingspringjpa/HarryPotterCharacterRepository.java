package com.telstra.usingspringjpa;


import org.springframework.data.jpa.repository.JpaRepository;

public interface HarryPotterCharacterRepository extends JpaRepository<HarryPotterCharacter, String> {

}
