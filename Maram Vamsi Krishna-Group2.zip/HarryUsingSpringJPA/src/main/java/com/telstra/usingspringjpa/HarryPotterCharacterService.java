package com.telstra.usingspringjpa;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HarryPotterCharacterService {
	private HarryPotterCharacterRepository characterRepository;
	
	@Autowired
	public HarryPotterCharacterService(HarryPotterCharacterRepository characterRepository) {
		this.characterRepository=characterRepository;
	}
	
	public List<HarryPotterCharacter> getAllCharacters(){
		return characterRepository.findAll();
	}
	public Optional<HarryPotterCharacter> getCharacterByName(String Name){
		return characterRepository.findById(Name);
	}
	public HarryPotterCharacter createCharacter(HarryPotterCharacter character) {
		return characterRepository.save(character);
	}
	
	public HarryPotterCharacter updateCharacter(String Name,HarryPotterCharacter character) {
		if(characterRepository.existsById(Name)) {
			character.setName(Name);
			return characterRepository.save(character);
		}
		return null;
	}
	public void deleteCharacter(String Name) {
		characterRepository.deleteById(Name);
	}
}
