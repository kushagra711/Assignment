package com.telstra.usingspringjpa;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class HarryPotterCharacter {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	String Name;
	
	String House;
	String Role;
	String Status;
	String Dies;
	public HarryPotterCharacter(String name, String house, String role, String status, String dies) {
		super();
		Name = name;
		House = house;
		Role = role;
		Status = status;
		Dies = dies;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getHouse() {
		return House;
	}
	public void setHouse(String house) {
		House = house;
	}
	public String getRole() {
		return Role;
	}
	public void setRole(String role) {
		Role = role;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getDies() {
		return Dies;
	}
	public void setDies(String dies) {
		Dies = dies;
	}
	@Override
	public String toString() {
		return "HarryPotterCharacter [Name=" + Name + ", House=" + House + ", Role=" + Role + ", Status=" + Status
				+ ", Dies=" + Dies + "]";
	}
	public HarryPotterCharacter(){
		
	}
	
}
