package com.harryporterbooks;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Book {
	private String name;
	private String house;
	private String role;
	private String status;
	private String dies;
	
	public Book(String name, String house, String role, String status, String dies) {
		super();
		this.name = name;
		this.house = house;
		this.role = role;
		this.status = status;
		this.dies = dies;
	}
	

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getHouse() {
		return house;
	}


	public void setHouse(String house) {
		this.house = house;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getDies() {
		return dies;
	}


	public void setDies(String dies) {
		this.dies = dies;
	}
	


	@Override
	public String toString() {
		return "Book [name=" + name + ", house=" + house + ", role=" + role + ", status=" + status + ", dies=" + dies
				+ "]";
	}
	
	@FunctionalInterface
	interface AddElements{
		void addelements(List<Book> harry,Book b);
		
		static void names(List<Book> b){
			for(Book bo:b) {
				if(bo.getHouse()=="Gryffindor") {
					System.out.println(bo.getName());
				}
			}
		}

		static void alive(List<Book> b) {
			for(Book bo:b) {
				if(bo.getDies()=="No" && bo.getHouse()=="Gryffindor") {
					 System.out.println(bo);
				}
				else if(bo.getDies()=="No" && bo.getHouse()=="RavenClaw") {
					 System.out.println(bo);
				}
				else if(bo.getDies()=="No" && bo.getHouse()=="Hufflepuff") {
					 System.out.println(bo);
				}
				else if(bo.getDies()=="No" && bo.getHouse()=="Slytherin") {
					 System.out.println(bo);
				}
			}
		}
		
		
		static void details(List<Book> b) {
			for(Book bo:b) {
				if(bo.getStatus()=="Family") {
					System.out.println(bo);
				}
			}
		}
		
		static void faculty(List<Book> b) {
			for(Book bo:b) {
				if(bo.getDies()=="yes" && bo.getRole()=="Faculty"){
				{
					System.out.println(bo);
				}
			}
		}
		}
		
	
	
	public static void main(String[] args) {
		
		List<Book> harrychar=new ArrayList<>();
		
		AddElements add=(a,b)->
		{
			a.add(b);
		};
		
		add.addelements(harrychar,new Book("HarryPotter","Gryffindor","Student","Self","No"));
		add.addelements(harrychar,new Book("Ginny Weasley","Gryffindor","Student","Friend","No"));
		add.addelements(harrychar,new Book("Ron Weasley","Gryffindor","Student","Friend","No"));
		add.addelements(harrychar,new Book("Hermione Granger","Gryffindor","Student","Friend","No"));
		add.addelements(harrychar,new Book("Neville Longbottom","Gryffindor","Student","Friend","No"));
		add.addelements(harrychar,new Book("Oliver wood","Gryffindor","Student","Friend","No"));
		add.addelements(harrychar,new Book("Luna Lovegood","RavenClaw","Student","Friend","No"));
		add.addelements(harrychar,new Book("Cho Chang","RavenClaw","Student","Friend","No"));
		add.addelements(harrychar,new Book("Cedric Diggory","Hufflepuff","Student","Friend","Yes"));
		add.addelements(harrychar,new Book("Hannah Abott","Hufflepuff","Student","Friend","No"));
		add.addelements(harrychar,new Book("Draco Malfoy","Slytherin","Student","Enemy","No"));
		add.addelements(harrychar,new Book("Vincent Crabbe","Slytherin","Student","Enemy","Yes"));
		add.addelements(harrychar,new Book("Gregory Goyle","Slytherin","Student","Enemy","No"));
		add.addelements(harrychar,new Book("Penelope Clearwater","Slytherin","Student","Enemy","No"));
		add.addelements(harrychar,new Book("Albus Dumbledore","Gryffindor","Faculty","Friend","Yes"));
		add.addelements(harrychar,new Book("Severus Snape","Slytherin","Faculty","Enemy","Yes"));
		add.addelements(harrychar,new Book("Remus Lupin","Gryffindor","Faculty","Friend","Yes"));
		add.addelements(harrychar,new Book("Horace Slughorn","Slytherin","Faculty","Friend","No"));
		add.addelements(harrychar,new Book("Rubeus Hagrid","Gryffindor","Faculty","Friend","No"));
		add.addelements(harrychar,new Book("Minerva McGonagall","Gryffindor","Faculty","Friend","No"));
		add.addelements(harrychar,new Book("James Potter","Gryffindor","Student","Family","Yes"));
		add.addelements(harrychar,new Book("Sirius Black","Gryffindor","Student","Friend","Yes"));
		add.addelements(harrychar,new Book("Lily Potter","Gryffindor","Student","Family","Yes"));
		add.addelements(harrychar,new Book("Peter Pettigrew","Gryffindor","Student","Enemy","Yes"));
		add.addelements(harrychar,new Book("Tom Morvolo Riddle","Slytherin","Student","Enemy","Yes"));
		harrychar.forEach(p->System.out.println(p));
		System.out.println("-----------------------------");
		AddElements.names(harrychar);
		System.out.println("-----------------------------");
		AddElements.alive(harrychar);
		System.out.println("-----------------------------");
		AddElements.details(harrychar);
		System.out.println("-----------------------------");
		
		
			
		}
		
	}
}



