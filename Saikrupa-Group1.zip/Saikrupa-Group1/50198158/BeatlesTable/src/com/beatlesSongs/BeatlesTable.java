package com.beatlesSongs;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

class BeatlesSong {

    private String name;

    private String type;

    private String releaseDate;

 

    public BeatlesSong(String name, String type, String releaseDate) {

        this.name = name;

        this.type = type;

        this.releaseDate = releaseDate;

    }

 

    public String getName() {

        return name;

    }

 

    public String getType() {

        return type;

    }

 

    public String getReleaseDate() {

        return releaseDate;

    }

}

 

public class BeatlesTable {

    private List<BeatlesSong> songs = new ArrayList<>();

 

    public void insertSong(String name, String type, String releaseDate) {

        songs.add(new BeatlesSong(name, type, releaseDate));

    }

 

    public List<BeatlesSong> getSinglesBeforeThanksgiving1965() {

        return songs.stream()

            .filter(song -> song.getType().equals("Single"))

            .filter(song -> song.getReleaseDate().compareTo("1965-11-26") < 0)

            .collect(Collectors.toList());

    }

 

    public List<BeatlesSong> getSinglesAndLPsSorted() {

        return songs.stream()

            .filter(song -> song.getType().equals("Single") || song.getType().equals("LP"))

            .sorted(Comparator.comparing(BeatlesSong::getReleaseDate))

            .collect(Collectors.toList());

    }

 

    public long getTotalCounts(String type) {

        return songs.stream()

            .filter(song -> song.getType().equals(type))

            .count();

    }

 

    public void getCountsPerYear() {

        songs.stream()

            .collect(Collectors.groupingBy(

                song -> song.getReleaseDate().substring(0, 4),

                Collectors.groupingBy(

                    BeatlesSong::getType,

                    Collectors.counting())))

            .forEach((year, counts) -> {

                System.out.println("Year: " + year);

                counts.forEach((type, count) -> System.out.println(type + ": " + count));

            });

    }

 

    public static void main(String[] args) {

        BeatlesTable table = new BeatlesTable();

        

        // Inserting the data

        table.insertSong("Love Me Do / P.S. I Love You", "Single", "1962-10-05");

        table.insertSong("Please Please Me", "LP", "1963-01-11");

        table.insertSong("From Me To You / Thank You Girl", "Single", "1963-04-12");

        table.insertSong("She Loves You / I’ll Get You", "Single", "1963-08-23");

        table.insertSong("I Want To Hold Your Hand / This Boy", "Single", "1963-11-29");

        table.insertSong("Can’t Buy Me Love / You Can’t Do That", "Single", "1964-03-20");

        table.insertSong("Long Tall Sally / I Call Your Name / Slow Down / Match Box", "EP", "1964-07-10");

        table.insertSong("A Hard Day’s Night", "LP", "1964-07-10");

        table.insertSong("I Feel Fine / She’s A Woman", "Single", "1964-11-27");

        table.insertSong("Beatles For Sale", "LP", "1964-12-04");

        table.insertSong("Ticket To Ride / Yes It Is", "Single", "1965-04-09");

        table.insertSong("Help! / I’m Down", "Single", "1965-07-23");

        table.insertSong("Help!", "LP", "1965-08-06");

        table.insertSong("We Can Work It Out / Day Tripper", "Single", "1965-12-03");

        table.insertSong("Rubber Soul", "LP", "1965-12-03");

        table.insertSong("Paperback Writer / Rain", "Single", "1966-06-10");

        table.insertSong("Yellow Submarine", "Single", "1966-08-05");

        table.insertSong("Revolver", "LP", "1966-08-28");

        table.insertSong("Strawberry Fields Forever / Penny Lane", "Single", "1967-02-13");

        table.insertSong("Sgt. Pepper’s Lonely Hearts Club Band", "LP", "1967-06-01");

        table.insertSong("All You Need Is Love / Baby You’re A Rich Man", "Single", "1967-07-07");

        table.insertSong("Hello Goodbye / I Am The Walrus", "Single", "1967-11-24");

        table.insertSong("Magical Mystery Tour", "EP", "1967-11-27");

        table.insertSong("Lady Madonna / The Inner Light", "Single", "1968-03-15");

        table.insertSong("Hey Jude / Revolution", "Single", "1968-08-30");

        table.insertSong("The Beatles (aka The White Album)", "LP", "1968-11-22");

        table.insertSong("Yellow Submarine", "LP", "1969-01-17");

        table.insertSong("Get Back / Don’t Let Me Down", "Single", "1969-04-11");

        table.insertSong("The Ballad of John and Yoko / Old Brown Shoe", "Single", "1969-05-3");

        table.insertSong("Abbey Road", "LP", "1969-09-26");

        table.insertSong("Let It Be / You Know My Name (Look Up The Number)", "Single", "1970-03-6");

        table.insertSong("The Long and Winding Road / For You Blue", "Single", "1970-05-11");

        table.insertSong("Let It Be", "LP", "1970-05-18");

        

        // Get singles before Thanksgiving 1965

        List<BeatlesSong> singlesBeforeThanksgiving1965 = table.getSinglesBeforeThanksgiving1965();

        System.out.println("Singles before Thanksgiving 1965:");

        printTable(singlesBeforeThanksgiving1965);

 

        // Get singles and LPs sorted

        List<BeatlesSong> singlesAndLPsSorted = table.getSinglesAndLPsSorted();

        System.out.println("Singles and LPs sorted:");

        printTable(singlesAndLPsSorted);

 

        // Get total counts

        System.out.println("Total Singles: " + table.getTotalCounts("Single"));

        System.out.println("Total EPs: " + table.getTotalCounts("EP"));

        System.out.println("Total LPs: " + table.getTotalCounts("LP"));

 

        // Get counts per year

        System.out.println("Counts per year:");

        table.getCountsPerYear();

    }

    

    class BeatlesSong {

        private String name;

        private String type;

        private String releaseDate;

 

        public BeatlesSong(String name, String type, String releaseDate) {

            this.name = name;

            this.type = type;

            this.releaseDate = releaseDate;

        }

 

        public String getName() {

            return name;

        }

 

        public String getType() {

            return type;

        }

 

        public String getReleaseDate() {

            return releaseDate;

        }

 

        @Override

        public String toString() {

            return "\"" + name + "\" (" + type + ") - " + releaseDate;

        }

    }

    public static void printTable(List<BeatlesSong> songs) {

        System.out.println("-----------------------------------------------------------------------------------");

        System.out.printf("| %-70s | %-10s | %-10s |\n", "Name", "Type", "Release Date");

        System.out.println("-----------------------------------------------------------------------------------");

 

        for (BeatlesSong song : songs) {

            System.out.printf("| %-70s | %-10s | %-10s |\n", song.getName(), song.getType(), song.getReleaseDate());

        }

 

        System.out.println("-----------------------------------------------------------------------------------");

    }

 

}