package com.demo.operations;

import java.sql.SQLException;

public interface Transactions {

	void createAndInsert() throws SQLException;
	void singlesBeforeThanksGiving() throws SQLException;
	void totalCountBySinglesLpEp() throws SQLException;
}
