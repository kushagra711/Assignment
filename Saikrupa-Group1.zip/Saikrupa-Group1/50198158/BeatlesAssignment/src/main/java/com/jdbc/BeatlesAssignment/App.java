package com.jdbc.BeatlesAssignment;

import java.sql.SQLException;

import com.demo.connection.DbConnection;
import com.demo.operations.DbOperations;

public class App 
{
    public static void main( String[] args ) throws ClassNotFoundException, SQLException
    {
    	Class.forName("com.mysql.cj.jdbc.Driver");

        DbConnection dbConnection = new DbConnection();
        System.out.println("connection established");
        DbOperations createAndInsetValue = new DbOperations();
        createAndInsetValue.totalCountBySinglesLpEp();

        dbConnection.getC().close();
    }
}
