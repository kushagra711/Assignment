package com.myjdbcdemo.myJdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyTasks 
{
    public static void main( String[] args )
    {
    	createCharacterList();
    	
    	String jdbcUrl = "jdbc:mysql://localhost:3306/telstra";
        String username = "root";
        String password = "Suhas@17";
        
        try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				System.out.println("Driver Loaded");
				Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
				System.out.println("Connection Establised");
				
				
				/*
				String insertquery = "INSERT INTO characters (id,name, house, role, status, dies) VALUES (?,?, ?, ?, ?, ?)";
				int i=0;
				for(Character character : characters) {
				PreparedStatement preparedStatement = connection.prepareStatement(insertquery);
				preparedStatement.setInt(1, i);
				preparedStatement.setString(2, character.getName());
	            preparedStatement.setString(3, character.getHouse());
	            preparedStatement.setString(4, character.getRole());
	            preparedStatement.setString(5, character.getStatus());
	            preparedStatement.setString(6, character.getDies());
	            preparedStatement.executeUpdate();
	            i++;
				}*/
				System.out.println("All Data inserted successfully!");
				
				System.out.println("\n");
				System.out.println("Task 2");
				String house = "Gryffindor";
				List<String> names = getCharacterNamesByHouse(connection,house);
				System.out.println("Names of People of "+house+": ");
				for(String name : names)
					System.out.println(name);
				
				System.out.println("\n");
				System.out.println("Task 3");
				Map<String, List<Character>> houseMap = getAliveCharactersByHouse(connection);
			    for (Map.Entry<String, List<Character>> entry : houseMap.entrySet()) {
			        String housename = entry.getKey();
			        List<Character> characters = entry.getValue();
			        
			        System.out.println("House: " + housename);
			        for (Character character : characters) 
			            System.out.println(character);
			        }
			    
			    System.out.println("\n");
			    System.out.println("Task 4");
			    List<Character> harryPotterFamilyMembers = getHarryPotterFamilyMembers(connection);
			    System.out.println("Family members of Harry Potter:");
			    for (Character character : harryPotterFamilyMembers)
			        System.out.println(character);
			    
			    System.out.println("\n");
			    System.out.println("Task 5");
			    List<Character> FacultyMembersWhoDied = getFacultyMembersWhoDied(connection);
			    System.out.println("Faculty Members who died:");
			    for (Character character : FacultyMembersWhoDied)
			        System.out.println(character);
        }
			
		catch (ClassNotFoundException e) {
				e.printStackTrace();
			} 
        catch (SQLException e) {
				e.printStackTrace();
			}
    }
    
    public static List<String> getCharacterNamesByHouse(Connection connection, String house) {
    	
    	List<String> nameList = new ArrayList<String>();
    	try {
    			String getnamebyhousequery = "SELECT name FROM characters WHERE house = ?";
    			PreparedStatement getNamebyHouseStatement = connection.prepareStatement(getnamebyhousequery);
    			getNamebyHouseStatement.setString(1, house);
    			ResultSet resultSet = getNamebyHouseStatement.executeQuery();
    			while (resultSet.next()) {
    				String name = resultSet.getString("name");
    				nameList.add(name);
    			}
    		} 
    catch (SQLException e) {
			e.printStackTrace();
		}
		return nameList;
    }
    
    public static Map<String, List<Character>> getAliveCharactersByHouse(Connection connection) {
        Map<String, List<Character>> houseMap = new HashMap<String, List<Character>>();
        
        try {
            String query = "SELECT * FROM characters WHERE dies = 'No'";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();
            
            while (resultSet.next()) {
                String house = resultSet.getString("house");
                String name = resultSet.getString("name");
                String role = resultSet.getString("role");
                String status = resultSet.getString("status");
                String dies = resultSet.getString("dies");
                
                Character character = new Character(name, house, role, status, dies);
                
                houseMap.computeIfAbsent(house, k -> new ArrayList<Character>()).add(character);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return houseMap;
    }
    
    public static List<Character> getHarryPotterFamilyMembers(Connection connection) {
        List<Character> familyMembers = new ArrayList<>();
        
        try {
            String query = "SELECT * FROM characters WHERE status = 'Family'";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();
            
            while (resultSet.next()) {
                String name = resultSet.getString("name");
                String house = resultSet.getString("house");
                String role = resultSet.getString("role");
                String status = resultSet.getString("status");
                String dies = resultSet.getString("dies");
                
                Character character = new Character(name, house, role, status, dies);
                familyMembers.add(character);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return familyMembers;
    }

    public static List<Character> getFacultyMembersWhoDied(Connection connection) {
        List<Character> facultyMembers = new ArrayList<>();
        
        try {
            String query = "SELECT * FROM characters WHERE role = 'Faculty' AND dies = 'Yes' ORDER BY name";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();
            
            while (resultSet.next()) {
                String name = resultSet.getString("name");
                String house = resultSet.getString("house");
                String role = resultSet.getString("role");
                String status = resultSet.getString("status");
                String dies = resultSet.getString("dies");
                
                Character character = new Character(name, house, role, status, dies);
                facultyMembers.add(character);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return facultyMembers;
    }

    
    public static void createCharacterList() {
        
		List<Character> characters = new ArrayList<Character>();

        characters.add(new Character("Harry Potter", "Gryffindor", "Student", "Self", "No"));
        characters.add(new Character("Ginny Weasley", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Ron Weasley", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Hermione Granger", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Neville Longbottom", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Oliver Wood", "Gryffindor", "Student", "Friend", "No"));

        characters.add(new Character("Luna Lovegood", "Ravenclaw", "Student", "Friend", "No"));
        characters.add(new Character("Cho Chang", "Ravenclaw", "Student", "Friend", "No"));

        characters.add(new Character("Cedric Diggory", "Hufflepuff", "Student", "Friend", "Yes"));
        characters.add(new Character("Hannah Abbot", "Hufflepuff", "Student", "Friend", "No"));

        characters.add(new Character("Draco Malfoy", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new Character("Vincent Crabbe", "Slytherin", "Student", "Enemy", "Yes"));
        characters.add(new Character("Gregory Goyle", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new Character("Penelope Clearwater", "Slytherin", "Student", "Enemy", "No"));

        characters.add(new Character("Albus Dumbledore", "Gryffindor", "Faculty", "Friend", "Yes"));
        characters.add(new Character("Severus Snape", "Slytherin", "Faculty", "Enemy", "Yes"));
        characters.add(new Character("Remus Lupin", "Gryffindor", "Faculty", "Friend", "Yes"));
        characters.add(new Character("Horace Slughorn", "Slytherin", "Faculty", "Friend", "No"));
        characters.add(new Character("Rubeus Hagrid", "Gryffindor", "Faculty", "Friend", "No"));
        characters.add(new Character("Minerva McGonagall", "Gryffindor", "Faculty", "Friend", "No"));

        characters.add(new Character("James Potter", "Gryffindor", "Student", "Family", "Yes"));
        characters.add(new Character("Sirius Black", "Gryffindor", "Student", "Friend", "Yes"));
        characters.add(new Character("Lily Potter", "Gryffindor", "Student", "Family", "Yes"));
        characters.add(new Character("Peter Pettigrew", "Gryffindor", "Student", "Enemy", "Yes"));
        characters.add(new Character("Tom Marvolo Riddle", "Slytherin", "Student", "Enemy", "Yes"));

    }

}