package com.myapp;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {

	List<Character> characters = createCharacterList();

@GetMapping("/allcharacters")
public List<Character> getCharacterList()
{
	return characters;
}

@GetMapping("/charactersByHouse")
public List<String> getCharactersByHouse(@RequestParam String houseName) {
    
	List<String> characterNamesByHouse = new ArrayList<>();
    for (Character character : characters) {
        if (character.getHouse().equalsIgnoreCase(houseName)) {
            characterNamesByHouse.add(character.getName());
        }
    }
    
    return characterNamesByHouse;
}

@GetMapping("/aliveCharacters")
public Map<String, List<Character>> getAliveCharactersByHouse() {
	
    return MyController.groupAliveCharactersByHouse(characters);
}


@GetMapping("/harryPotterMembers")
public List<Character> getHarryPotterFamilyMembers(@RequestParam String status) 
{
	return MyController.harryPotterFamilyMembers(characters,status);
}


@GetMapping("/MembersByRoleandDeath")
public List<Character> getDeadFacultyMembers(
        @RequestParam String role,
        @RequestParam String dies) {
    return MyController.getDeadFacultyMembers(characters, role, dies);
}


public static List<Character> getDeadFacultyMembers(List<Character> characters, String role, String dies) {
    return characters.stream()
            .filter(character -> character.getRole().equalsIgnoreCase(role) &&
                    character.getDies().equalsIgnoreCase(dies))
            .sorted(Comparator.comparing(Character::getName))
            .collect(Collectors.toList());
}


public static List<Character> harryPotterFamilyMembers(List<Character> characters, String status)
{
	
return characters.stream()
        .filter(character -> character.getStatus().equalsIgnoreCase(status))
        .collect(Collectors.toList());
}



public static Map<String, List<Character>> groupAliveCharactersByHouse(List<Character> characters) {
    Map<String, List<Character>> aliveCharactersByHouse = new HashMap<>();
    for (Character character : characters) {
        if (character.getDies().equalsIgnoreCase("Yes")) {
            aliveCharactersByHouse
                    .computeIfAbsent(character.getHouse(), k -> new ArrayList<>())
                    .add(character);
        }
    }
    
    return aliveCharactersByHouse;
}



public static List<Character> createCharacterList() {
    
	List<Character> characters = new ArrayList<Character>();

    characters.add(new Character("Harry Potter", "Gryffindor", "Student", "Self", "No"));
    characters.add(new Character("Ginny Weasley", "Gryffindor", "Student", "Friend", "No"));
    characters.add(new Character("Ron Weasley", "Gryffindor", "Student", "Friend", "No"));
    characters.add(new Character("Hermione Granger", "Gryffindor", "Student", "Friend", "No"));
    characters.add(new Character("Neville Longbottom", "Gryffindor", "Student", "Friend", "No"));
    characters.add(new Character("Oliver Wood", "Gryffindor", "Student", "Friend", "No"));

    characters.add(new Character("Luna Lovegood", "Ravenclaw", "Student", "Friend", "No"));
    characters.add(new Character("Cho Chang", "Ravenclaw", "Student", "Friend", "No"));

    characters.add(new Character("Cedric Diggory", "Hufflepuff", "Student", "Friend", "Yes"));
    characters.add(new Character("Hannah Abbot", "Hufflepuff", "Student", "Friend", "No"));

    characters.add(new Character("Draco Malfoy", "Slytherin", "Student", "Enemy", "No"));
    characters.add(new Character("Vincent Crabbe", "Slytherin", "Student", "Enemy", "Yes"));
    characters.add(new Character("Gregory Goyle", "Slytherin", "Student", "Enemy", "No"));
    characters.add(new Character("Penelope Clearwater", "Slytherin", "Student", "Enemy", "No"));

    characters.add(new Character("Albus Dumbledore", "Gryffindor", "Faculty", "Friend", "Yes"));
    characters.add(new Character("Severus Snape", "Slytherin", "Faculty", "Enemy", "Yes"));
    characters.add(new Character("Remus Lupin", "Gryffindor", "Faculty", "Friend", "Yes"));
    characters.add(new Character("Horace Slughorn", "Slytherin", "Faculty", "Friend", "No"));
    characters.add(new Character("Rubeus Hagrid", "Gryffindor", "Faculty", "Friend", "No"));
    characters.add(new Character("Minerva McGonagall", "Gryffindor", "Faculty", "Friend", "No"));

    characters.add(new Character("James Potter", "Gryffindor", "Student", "Family", "Yes"));
    characters.add(new Character("Sirius Black", "Gryffindor", "Student", "Friend", "Yes"));
    characters.add(new Character("Lily Potter", "Gryffindor", "Student", "Family", "Yes"));
    characters.add(new Character("Peter Pettigrew", "Gryffindor", "Student", "Enemy", "Yes"));
    characters.add(new Character("Tom Marvolo Riddle", "Slytherin", "Student", "Enemy", "Yes"));

    return characters;
}

}