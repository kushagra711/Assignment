package com.myapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsingRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsingRestApplication.class, args);
	}

}
