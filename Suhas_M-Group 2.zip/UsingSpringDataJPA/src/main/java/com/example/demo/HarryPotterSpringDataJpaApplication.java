package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EntityScan(basePackages = "com.example.demo") // Make sure this matches the package containing your entity
@ComponentScan(basePackages = "com.example.demo")
public class HarryPotterSpringDataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(HarryPotterSpringDataJpaApplication.class, args);
	}

}
