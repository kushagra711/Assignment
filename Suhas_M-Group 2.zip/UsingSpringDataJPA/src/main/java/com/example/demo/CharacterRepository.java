package com.example.demo;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CharacterRepository extends JpaRepository<Character, Long> {
    List<Character> findByHouse(String house);
    List<Character> findByStatus(String status);
    List<Character> findByRoleAndDies(String role, String dies);
}
