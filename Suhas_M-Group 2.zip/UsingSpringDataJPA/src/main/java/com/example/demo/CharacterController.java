package com.example.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/characters")
public class CharacterController {

    @Autowired
    private CharacterRepository characterRepository;

    @GetMapping("/gryffindor")
    public List<Character> getGryffindorCharacters() {
        return characterRepository.findByHouse("Gryffindor");
    }

    @GetMapping("/alive")
    public List<Character> getAliveCharacters() {
        return characterRepository.findByStatus("No");
    }

    @GetMapping("/dying-faculty")
    public List<Character> getDyingFacultyMembers() {
        return characterRepository.findByRoleAndDies("Faculty", "Yes");
    }
}

