package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Character {
    @Id
    private Long id;
    private String name;
    private String house;
    private String role;
    private String status;
    private String dies;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHouse() {
		return house;
	}
	public void setHouse(String house) {
		this.house = house;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDies() {
		return dies;
	}
	public void setDies(String dies) {
		this.dies = dies;
	}
	public Character(Long id, String name, String house, String role, String status, String dies) {
		super();
		this.id = id;
		this.name = name;
		this.house = house;
		this.role = role;
		this.status = status;
		this.dies = dies;
	}
    public Character() {
        
    }

}

