package com.myassignment;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Map;

public class MyTasks {

	public static void main(String[] args) {
		
		List<Character> characters = createCharacterList();
		
		System.out.println("Task 1");
		characters.forEach(x-> System.out.println(x));
		
		System.out.println("\n\n");	
		
		System.out.println("Task 2");
		String house = "Gryffindor";
		List<String> names = getCharacterNamesByHouse(characters,house);
		names.forEach(x->System.out.println(x));
		
		System.out.println("\n\n");
		
		System.out.println("Task 3");
		Map<String, List<Character>> aliveGroup = groupAliveCharactersByHouse(characters);
		aliveGroup.forEach((h,list)->System.out.println("House: "+h+" "+"Character: "+list)) ;
		
		System.out.println("\n\n");	
		
		System.out.println("Task 4");
		String status = "Family";
		List<Character> familyMembers = getHarryPottersMembersByStatus(characters,status);
		familyMembers.forEach(x->System.out.println(x));
		
		System.out.println("\n\n");	
		
		System.out.println("Task 5");
		List<Character> deadFacultyMembers = getSortedDeadFaculty(characters);
		deadFacultyMembers.forEach(x->System.out.println(x));
}
	public static List<String> getCharacterNamesByHouse(List<Character> characters, String house) {
        return characters.stream()
                .filter(character -> character.getHouse().equals(house))
                .map(Character::getName)
                .collect(Collectors.toList());
    }
	
	public static Map<String, List<Character>> groupAliveCharactersByHouse(List<Character> characters) {
        return characters.stream()
                .filter(character -> character.getDies().equalsIgnoreCase("No"))
                .collect(Collectors.groupingBy(Character::getHouse));
    }
	
	public static List<Character> getHarryPottersMembersByStatus(List<Character> characters, String status) {
        return characters.stream()
                .filter(character -> character.getStatus().equals(status))
                .collect(Collectors.toList());
    }
	
	public static List<Character> getSortedDeadFaculty(List<Character> characters) {
        return characters.stream()
                .filter(character -> character.getRole().equals("Faculty"))
                .filter(character -> character.getDies().equals("Yes"))
                .sorted((c1, c2) -> c1.getName().compareToIgnoreCase(c2.getName()))
                .collect(Collectors.toList());
    }
	
	public static List<Character> createCharacterList() {
        
		List<Character> characters = new ArrayList<Character>();

        characters.add(new Character("Harry Potter", "Gryffindor", "Student", "Self", "No"));
        characters.add(new Character("Ginny Weasley", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Ron Weasley", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Hermione Granger", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Neville Longbottom", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Oliver Wood", "Gryffindor", "Student", "Friend", "No"));

        characters.add(new Character("Luna Lovegood", "Ravenclaw", "Student", "Friend", "No"));
        characters.add(new Character("Cho Chang", "Ravenclaw", "Student", "Friend", "No"));

        characters.add(new Character("Cedric Diggory", "Hufflepuff", "Student", "Friend", "Yes"));
        characters.add(new Character("Hannah Abbot", "Hufflepuff", "Student", "Friend", "No"));

        characters.add(new Character("Draco Malfoy", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new Character("Vincent Crabbe", "Slytherin", "Student", "Enemy", "Yes"));
        characters.add(new Character("Gregory Goyle", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new Character("Penelope Clearwater", "Slytherin", "Student", "Enemy", "No"));

        characters.add(new Character("Albus Dumbledore", "Gryffindor", "Faculty", "Friend", "Yes"));
        characters.add(new Character("Severus Snape", "Slytherin", "Faculty", "Enemy", "Yes"));
        characters.add(new Character("Remus Lupin", "Gryffindor", "Faculty", "Friend", "Yes"));
        characters.add(new Character("Horace Slughorn", "Slytherin", "Faculty", "Friend", "No"));
        characters.add(new Character("Rubeus Hagrid", "Gryffindor", "Faculty", "Friend", "No"));
        characters.add(new Character("Minerva McGonagall", "Gryffindor", "Faculty", "Friend", "No"));

        characters.add(new Character("James Potter", "Gryffindor", "Student", "Family", "Yes"));
        characters.add(new Character("Sirius Black", "Gryffindor", "Student", "Friend", "Yes"));
        characters.add(new Character("Lily Potter", "Gryffindor", "Student", "Family", "Yes"));
        characters.add(new Character("Peter Pettigrew", "Gryffindor", "Student", "Enemy", "Yes"));
        characters.add(new Character("Tom Marvolo Riddle", "Slytherin", "Student", "Enemy", "Yes"));

        return characters;
    }
}