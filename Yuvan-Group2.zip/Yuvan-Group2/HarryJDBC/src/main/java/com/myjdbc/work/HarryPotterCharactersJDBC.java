package com.myjdbc.work;

import java.sql.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class CharacterInfo {
    String name;
    String house;
    String role;
    String status;
    String dies;

    public CharacterInfo(String name, String house, String role, String status, String dies) {
        this.name = name;
        this.house = house;
        this.role = role;
        this.status = status;
        this.dies = dies;
    }

    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
    public String toString() {
        return "CharacterInfo [name=" + name + ", house=" + house + ", role=" + role + ", status=" + status + ", dies=" + dies + "]";
    }
}

public class HarryPotterCharactersJDBC {
    public static void main(String[] args) throws Exception {

        String jdbcUrl = "jdbc:mysql://localhost:3306/telstra";
        String username = "root";
        String password = "root";

        Class.forName("com.mysql.cj.jdbc.Driver");
        System.out.println("Loaded Driver");

        Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
        System.out.println("Connection established");

        List<CharacterInfo> characters = createCharacterList();

        String insertSql = "INSERT INTO harrypotter (name, house, role, status, dies) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(insertSql)) {
            for (CharacterInfo character : characters) {
                preparedStatement.setString(1, character.name);
                preparedStatement.setString(2, character.house);
                preparedStatement.setString(3, character.role);
                preparedStatement.setString(4, character.status);
                preparedStatement.setString(5, character.dies);
                preparedStatement.executeUpdate();
            }

            System.out.println("Characters inserted into the database.");
        }
        List<String> gryffindorCharacters = getGryffindorCharacterNames(connection);
        System.out.println("\nGryffindor Characters:\n");
        gryffindorCharacters.forEach(System.out::println);
        
        List<CharacterInfo> harryFamilyMembers = getFamilyMembersOfHarry(connection);
        System.out.println("\nFamily Members of Harry Potter:\n");
        harryFamilyMembers.forEach(System.out::println);
        
        List<CharacterInfo> dyingFacultyMembers = getDyingFacultyMembers(connection);
        System.out.println("\nDying Faculty Members (Sorted Alphabetically):\n");
        dyingFacultyMembers.forEach(System.out::println);
        
        Map<String, List<CharacterInfo>> charactersByHouse = groupCharactersByHouse(connection);
        System.out.println("\nCharacters Grouped by House:\n");
        charactersByHouse.forEach((house, chars) -> {
            System.out.println("\nHouse: " + house);
            chars.forEach(System.out::println);
        });
    }

  
    
    
    
    
    private static List<CharacterInfo> createCharacterList() {
        List<CharacterInfo> characters = new ArrayList<>();
        characters.add(new CharacterInfo("Harry Potter", "Gryffindor", "Student", "Self", "No"));
        characters.add(new CharacterInfo("Ginny Weasley", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new CharacterInfo("Ron Weasley", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new CharacterInfo("Hermione Granger", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new CharacterInfo("Neville Longbottom", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new CharacterInfo("Oliver Wood", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new CharacterInfo("Luna Lovegood", "Ravenclaw", "Student", "Friend", "No"));
        characters.add(new CharacterInfo("Cho Chang", "Ravenclaw", "Student", "Friend", "No"));
        characters.add(new CharacterInfo("Cedric Diggory", "Hufflepuff", "Student", "Friend", "Yes"));
        characters.add(new CharacterInfo("Hannah Abbot", "Hufflepuff", "Student", "Friend", "No"));
        characters.add(new CharacterInfo("Draco Malfoy", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new CharacterInfo("Vincent Crabbe", "Slytherin", "Student", "Enemy", "Yes"));
        characters.add(new CharacterInfo("Gregory Goyle", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new CharacterInfo("Penelope Clearwater", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new CharacterInfo("Albus Dumbledore", "Gryffindor", "Faculty", "Friend", "Yes"));
        characters.add(new CharacterInfo("Severus Snape", "Slytherin", "Faculty", "Enemy", "Yes"));
        characters.add(new CharacterInfo("Remus Lupin", "Gryffindor", "Faculty", "Friend", "Yes"));
        characters.add(new CharacterInfo("Horace Slughorn", "Slytherin", "Faculty", "Friend", "No"));
        characters.add(new CharacterInfo("Rubeus Hagrid", "Gryffindor", "Faculty", "Friend", "No"));
        characters.add(new CharacterInfo("Minerva McGonagall", "Gryffindor", "Faculty", "Friend", "No"));
        characters.add(new CharacterInfo("James Potter", "Gryffindor", "Student", "Family", "Yes"));
        characters.add(new CharacterInfo("Sirius Black", "Gryffindor", "Student", "Friend", "Yes"));
        characters.add(new CharacterInfo("Lily Potter", "Gryffindor", "Student", "Family", "Yes"));
        characters.add(new CharacterInfo("Peter Pettigrew", "Gryffindor", "Student", "Enemy", "Yes"));
        characters.add(new CharacterInfo("Tom Marvolo Riddle", "Slytherin", "Student", "Enemy", "Yes"));
        return characters;
    }
    
    
    public static List<String> getGryffindorCharacterNames(Connection connection) throws SQLException {
        List<String> gryffindorCharacterNames = new ArrayList<>();
        
        String selectSql = "SELECT name FROM harrypotter WHERE house = 'Gryffindor'";
        
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(selectSql)) {
            
            while (resultSet.next()) {
                String name = resultSet.getString("name");
                gryffindorCharacterNames.add(name);
            }
        }
        
        return gryffindorCharacterNames;
    }
    public static List<CharacterInfo> getFamilyMembersOfHarry(Connection connection) throws SQLException {
        List<CharacterInfo> familyMembersOfHarry = new ArrayList<>();
        
        String selectSql = "SELECT * FROM harrypotter WHERE status = 'Family'";
        
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(selectSql)) {
            
            while (resultSet.next()) {
                String name = resultSet.getString("name");
                String house = resultSet.getString("house");
                String role = resultSet.getString("role");
                String status = resultSet.getString("status");
                String dies = resultSet.getString("dies");
                
                CharacterInfo character = new CharacterInfo(name, house, role, status, dies);
                familyMembersOfHarry.add(character);
            }
        }
        
        return familyMembersOfHarry;
    }
    
    public static List<CharacterInfo> getDyingFacultyMembers(Connection connection) throws SQLException {
        List<CharacterInfo> dyingFacultyMembers = new ArrayList<>();
        
        String selectSql = "SELECT * FROM harrypotter WHERE role = 'Faculty' AND dies = 'Yes'";
        
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(selectSql)) {
            
            while (resultSet.next()) {
                String name = resultSet.getString("name");
                String house = resultSet.getString("house");
                String role = resultSet.getString("role");
                String status = resultSet.getString("status");
                String dies = resultSet.getString("dies");
                
                CharacterInfo character = new CharacterInfo(name, house, role, status, dies);
                dyingFacultyMembers.add(character);
            }
        }
        
       dyingFacultyMembers.sort(Comparator.comparing(CharacterInfo::getName));
        
        return dyingFacultyMembers;
    
 }
    public static Map<String, List<CharacterInfo>> groupCharactersByHouse(Connection connection) throws SQLException {
        Map<String, List<CharacterInfo>> charactersByHouse = new HashMap<>();
        
        String selectSql = "SELECT * FROM harrypotter WHERE dies = 'No'";
        
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(selectSql)) {
            
            while (resultSet.next()) {
                String name = resultSet.getString("name");
                String house = resultSet.getString("house");
                String role = resultSet.getString("role");
                String status = resultSet.getString("status");
                String dies = resultSet.getString("dies");
                
                CharacterInfo character = new CharacterInfo(name, house, role, status, dies);
                charactersByHouse.computeIfAbsent(house, k -> new ArrayList<>()).add(character);
            }
        }
        
        return charactersByHouse;
    }    
}


