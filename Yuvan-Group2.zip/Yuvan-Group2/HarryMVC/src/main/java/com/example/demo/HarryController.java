package com.example.demo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hp")
public class HarryController {

    private static List<HarryCharacter> characters = new ArrayList<>();

    static {
        characters.add(new HarryCharacter("Harry Potter", "Gryffindor", "Student", "Self", "No"));
        characters.add(new HarryCharacter("Ginny Weasley", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new HarryCharacter("Ron Weasley","Gryffindor","Student","Friend","No"));
        characters.add(new HarryCharacter("Ron Weasley", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new HarryCharacter("Hermione Granger", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new HarryCharacter("Neville Longbottom", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new HarryCharacter("Oliver Wood", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new HarryCharacter("Luna Lovegood", "Ravenclaw", "Student", "Friend", "No"));
        characters.add(new HarryCharacter("Cho Chang", "Ravenclaw", "Student", "Friend", "No"));
        characters.add(new HarryCharacter("Cedric Diggory", "Hufflepuff", "Student", "Friend", "Yes"));
        characters.add(new HarryCharacter("Hannah Abbot", "Hufflepuff", "Student", "Friend", "No"));
        characters.add(new HarryCharacter("Draco Malfoy", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new HarryCharacter("Vincent Crabbe", "Slytherin", "Student", "Enemy", "Yes"));
        characters.add(new HarryCharacter("Gregory Goyle", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new HarryCharacter("Penelope Clearwater", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new HarryCharacter("Albus Dumbledore", "Gryffindor", "Faculty", "Friend", "Yes"));
        characters.add(new HarryCharacter("Severus Snape", "Slytherin", "Faculty", "Enemy", "Yes"));
        characters.add(new HarryCharacter("Remus Lupin", "Gryffindor", "Faculty", "Friend", "Yes"));
        characters.add(new HarryCharacter("Horace Slughorn", "Slytherin", "Faculty", "Friend", "No"));
        characters.add(new HarryCharacter("Rubeus Hagrid", "Gryffindor", "Faculty", "Friend", "No"));
        characters.add(new HarryCharacter("Minerva McGonagall", "Gryffindor", "Faculty", "Friend", "No"));
        characters.add(new HarryCharacter("James Potter", "Gryffindor", "Student", "Family", "Yes"));
        characters.add(new HarryCharacter("Sirius Black", "Gryffindor", "Student", "Friend", "Yes"));
        characters.add(new HarryCharacter("Lily Potter", "Gryffindor", "Student", "Family", "Yes"));
        characters.add(new HarryCharacter("Peter Pettigrew", "Gryffindor", "Student", "Enemy", "Yes"));
        characters.add(new HarryCharacter("Tom Marvolo Riddle", "Slytherin", "Student", "Enemy", "Yes"));
    }

    @GetMapping("/allchar")
    public ArrayList<HarryCharacter> all() {
        return (ArrayList<HarryCharacter>) characters;
    }

    @GetMapping("/getchar/{name}")
    public HarryCharacter onechar(@PathVariable String name) {
        return characters.stream()
                .filter(character -> character.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }

    @GetMapping("/gethouse/{house}")
    public List<HarryCharacter> getCharactersByHouse(@PathVariable String house) {
        return characters.stream()
                .filter(character -> character.getHouse().equalsIgnoreCase(house))
                .collect(Collectors.toList());
    }
    
    @GetMapping("/groupedbyhouse")
    public Map<String, List<HarryCharacter>> aliveGroupedByHouse() {
        return groupByHouse(filterByDies("No"));
    }

    private Map<String, List<HarryCharacter>> groupByHouse(List<HarryCharacter> characters) {
        return characters.stream()
                .collect(Collectors.groupingBy(HarryCharacter::getHouse));
    }

    @GetMapping("/getstatus/{status}")
    public List<HarryCharacter> getCharactersByStatus(@PathVariable String status) {
        return characters.stream()
                .filter(character -> character.getStatus().equalsIgnoreCase(status))
                .collect(Collectors.toList());
    }
    
    
    @GetMapping("/harryfamily")
    public List<HarryCharacter> getCharactersByStatus() {
        return characters.stream()
                .filter(character -> character.getStatus().equalsIgnoreCase("family"))
                .collect(Collectors.toList());
    }

    @GetMapping("/getfaculty")
    public List<HarryCharacter> getFaculty() {
        return characters.stream()
                .filter(character -> character.getRole().equalsIgnoreCase("Faculty"))
                .collect(Collectors.toList());
    }

    @GetMapping("/getalive")
    public List<HarryCharacter> alive() {
        return filterByDies("No");
    }

    @GetMapping("/getdeadfaculty")
    public List<HarryCharacter> deadFaculty() {
        return filterByDiesAndRole("Yes", "Faculty");
    }

    private List<HarryCharacter> filterByDies(String dies) {
        return characters.stream()
                .filter(character -> character.getDies().equalsIgnoreCase(dies))
                .collect(Collectors.toList());
    }

    private List<HarryCharacter> filterByDiesAndRole(String dies, String role) {
        return characters.stream()
                .filter(character -> character.getDies().equalsIgnoreCase(dies))
                .filter(character -> character.getRole().equalsIgnoreCase(role))
                .sorted(Comparator.comparing(HarryCharacter::getName)) 
                .collect(Collectors.toList());
    }
}

