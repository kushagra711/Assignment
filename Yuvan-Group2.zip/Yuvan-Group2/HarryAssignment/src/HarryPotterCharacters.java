import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

class Character {
    String name;
    String house;
    String role;
    String status;
    String dies;

    public Character(String name, String house, String role, String status, String dies) {
        this.name = name;
        this.house = house;
        this.role = role;
        this.status = status;
        this.dies = dies;
    }

    @Override
    public String toString() {
        return "Character [name=" + name + ", house=" + house + ", role=" + role + ", status=" + status + ", dies="
                + dies + "]";
    }
}

public class HarryPotterCharacters{
    public static void main(String[] args) {
        List<Character> characters = createCharacterList();
        
        System.out.println("All Characters:\n");
        characters.forEach(System.out::println);

        List<String> gryffindorCharacters = getGryffindorCharacterNames(characters);
        System.out.println("\nGryffindor Characters:\n");
        gryffindorCharacters.forEach(System.out::println);

        Map<String, List<Character>> charactersByHouse = groupCharactersByHouse(characters);
        System.out.println("Characters Grouped by House:");
        charactersByHouse.forEach((house, chars) -> {
            System.out.println("\nHouse: " + house);
            chars.forEach(System.out::println);
        });
        
        List<Character> harryFamilyMembers = getFamilyMembersOfHarry(characters);
        System.out.println("Family Members of Harry Potter:");
        harryFamilyMembers.forEach(System.out::println);

        List<Character> dyingFacultyMembers = getDyingFacultyMembers(characters);
        System.out.println("\nFaculty Members Who Die (Sorted Alphabetically):");
        dyingFacultyMembers.forEach(System.out::println);
    }

    public static List<Character> createCharacterList() {
        List<Character> characters = new ArrayList<>();
        characters.add(new Character("Harry Potter", "Gryffindor", "Student", "Self", "No"));
        characters.add(new Character("Ginny Weasley", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Ron Weasley", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Hermione Granger", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Neville Longbottom", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Oliver Wood", "Gryffindor", "Student", "Friend", "No"));
        characters.add(new Character("Luna Lovegood", "Ravenclaw", "Student", "Friend", "No"));
        characters.add(new Character("Cho Chang", "Ravenclaw", "Student", "Friend", "No"));
        characters.add(new Character("Cedric Diggory", "Hufflepuff", "Student", "Friend", "Yes"));
        characters.add(new Character("Hannah Abbot", "Hufflepuff", "Student", "Friend", "No"));
        characters.add(new Character("Draco Malfoy", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new Character("Vincent Crabbe", "Slytherin", "Student", "Enemy", "Yes"));
        characters.add(new Character("Gregory Goyle", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new Character("Penelope Clearwater", "Slytherin", "Student", "Enemy", "No"));
        characters.add(new Character("Albus Dumbledore", "Gryffindor", "Faculty", "Friend", "Yes"));
        characters.add(new Character("Severus Snape", "Slytherin", "Faculty", "Enemy", "Yes"));
        characters.add(new Character("Remus Lupin", "Gryffindor", "Faculty", "Friend", "Yes"));
        characters.add(new Character("Horace Slughorn", "Slytherin", "Faculty", "Friend", "No"));
        characters.add(new Character("Rubeus Hagrid", "Gryffindor", "Faculty", "Friend", "No"));
        characters.add(new Character("Minerva McGonagall", "Gryffindor", "Faculty", "Friend", "No"));
        characters.add(new Character("James Potter", "Gryffindor", "Student", "Family", "Yes"));
        characters.add(new Character("Sirius Black", "Gryffindor", "Student", "Friend", "Yes"));
        characters.add(new Character("Lily Potter", "Gryffindor", "Student", "Family", "Yes"));
        characters.add(new Character("Peter Pettigrew", "Gryffindor", "Student", "Enemy", "Yes"));
        characters.add(new Character("Tom Marvolo Riddle", "Slytherin", "Student", "Enemy", "Yes"));
        return characters;
    }

    public static List<String> getGryffindorCharacterNames(List<Character> characters) {
        return characters.stream()
            .filter(c -> c.house.equals("Gryffindor"))
            .map(c -> c.name)
            .collect(Collectors.toList());
    }

    public static Map<String, List<Character>> groupCharactersByHouse(List<Character> characters) {
        return characters.stream()
            .filter(c -> c.dies.equals("No"))
            .collect(Collectors.groupingBy(c -> c.house));
    }
    public static List<Character> getFamilyMembersOfHarry(List<Character> characters) {
        return characters.stream()
            .filter(c ->c.status.equals("Family"))
            .collect(Collectors.toList());
    }

    public static List<Character> getDyingFacultyMembers(List<Character> characters) {
        return characters.stream()
            .filter(c -> c.role.equals("Faculty") && c.dies.equals("Yes"))
            .sorted(Comparator.comparing(c -> c.name))
            .collect(Collectors.toList());
    }
}