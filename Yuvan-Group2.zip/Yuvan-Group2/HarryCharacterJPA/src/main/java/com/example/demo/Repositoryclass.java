package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.Character;

import java.util.List;

@Repository
public interface Repositoryclass extends JpaRepository<Character, String> {
    List<Character> findByHouse(String house);
    List<Character> findByStatus(String status);
    List<Character> findByDies(String dies);
    List<Character> findByRoleAndDies(String role, String dies);
    
}

