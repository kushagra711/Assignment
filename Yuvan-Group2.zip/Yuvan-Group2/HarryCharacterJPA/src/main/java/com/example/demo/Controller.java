package com.example.demo;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Character;
import com.example.demo.Repositoryclass;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/hp")
public class Controller {

    @Autowired
    private Repositoryclass characterRepository;

    @GetMapping("/allchar")
    public List<Character> getAllCharacters() {
        return characterRepository.findAll();
    }

    @GetMapping("/gryffindor")
    public List<Character> getGryffindorCharacters() {
        return characterRepository.findByHouse("Gryffindor");
    }

 
    @GetMapping("/groupedbyhouse")
    public Map<String, List<Character>> getAliveCharactersGroupedByHouse() {
        List<Character> aliveCharacters = characterRepository.findByDies("No");
        
        return aliveCharacters.stream()
            .collect(Collectors.groupingBy(Character::getHouse));
    }

    @GetMapping("/harryfamily")
    public List<Character> getFamilyMembers() {
        return characterRepository.findByStatus("family");
    }

    @GetMapping("/die")
    public List<Character> getDyingFacultyMembers() {
        List<Character> dyingFacultyMembers = characterRepository.findByRoleAndDies("Faculty", "Yes");
        dyingFacultyMembers.sort(Comparator.comparing(Character::getName));
        return dyingFacultyMembers;
    }
}



