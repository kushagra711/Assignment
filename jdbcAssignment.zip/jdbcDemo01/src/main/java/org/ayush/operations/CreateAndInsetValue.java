package org.ayush.operations;

import org.ayush.connection.DbConnection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class CreateAndInsetValue implements DbTransactions{
    @Override
    public void createAndInsert() throws SQLException {
        DbConnection dbConnection = new DbConnection();

        Statement st = dbConnection.getC().createStatement();
        //		Your CREATE TABLE statement
//        String createTableSQL = "CREATE TABLE songs (id INT, year INT, type VARCHAR(255), title VARCHAR(255), release_date DATE)";
//        st.executeUpdate(createTableSQL);

        String[] insertStatements = {
                "INSERT INTO songs (year, type, title, release_date) VALUES (1962, 'Single', 'Love Me Do / P.S. I Love You', '1962-10-05')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1963, 'LP', 'Please Please Me', '1963-03-22')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1963, 'Single', 'From Me To You / Thank You Girl', '1963-04-11')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1963, 'Single', 'She Loves You / I\\'ll Get You', '1963-08-23')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1963, 'LP', 'With The Beatles', '1963-11-22')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1963, 'Single', 'Want To Hold Your Hand / This Boy', '1963-11-29')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1964, 'Single', 'Can\\'t Buy Me Love / You Can\\'t Do That', '1964-03-20')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1964, 'EP', 'Long Tall Sally / I Call Your Name / Slow Down / Matchbox', '1964-04-10')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1964, 'LP', 'A Hard Day\\'s Night', '1964-07-10')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1964, 'Single', 'I Feel Fine / She\\'s A Woman', '1964-11-27')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1964, 'LP', 'Beatles For Sale', '1964-12-04')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1965, 'Single', 'Ticket To Ride / Yes It Is', '1965-04-09')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1965, 'Single', 'Help! / I\\'m Down', '1965-07-23')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1965, 'LP', 'Help!', '1965-08-06')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1965, 'Single', 'We Can Work It Out / Day Tripper', '1965-12-03')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1965, 'LP', 'Rubber Soul', '1965-12-03')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1966, 'Single', 'Paperback Writer / Rain', '1966-06-10')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1966, 'LP', 'Revolver', '1966-08-05')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1966, 'Single', 'Yellow Submarine / Eleanor Rigby', '1966-08-05')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1966, 'Single', 'Strawberry Fields Forever / Penny Lane', '1967-02-13')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1967, 'LP', 'Sgt. Pepper\\'s Lonely Hearts Club Band', '1967-06-01')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1967, 'Single', 'All You Need Is Love / Baby You\\'re A Rich Man', '1967-07-07')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1967, 'Single', 'Hello Goodbye / I Am The Walrus', '1967-11-24')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1967, 'EP', 'Magical Mystery Tour', '1967-11-27')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1967, 'Single', 'Lady Madonna / The Inner Light', '1968-03-15')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1968, 'Single', 'Hey Jude / Revolution', '1968-08-30')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1968, 'LP', 'The Beatles (aka The White Album)', '1968-11-22')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1968, 'Single', 'Ob-La-Di, Ob-La-Da / While My Guitar Gently Weeps', '1968-11-27')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1968, 'Single', 'Get Back / Don\\'t Let Me Down', '1969-04-11')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1969, 'Single', 'The Ballad of John and Yoko / Old Brown Shoe', '1969-05-30')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1969, 'LP', 'Abbey Road', '1969-09-26')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1969, 'Single', 'Something / Come Together', '1969-10-31')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1970, 'Single', 'Let It Be / You Know My Name (Look Up The Number)', '1970-03-06')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1970, 'Single', 'The Long and Winding Road / For You Blue', '1970-05-11')",
                "INSERT INTO songs (year, type, title, release_date) VALUES (1970, 'LP', 'Let It Be', '1970-05-18')"
        };

//        for (String insertStatement : insertStatements) {
//            st.executeUpdate(insertStatement);
//        }

        ResultSet res = st.executeQuery("select * from songs");
        while(res.next()){
            System.out.println(res.getInt(1));
            System.out.println(res.getString(2));
            System.out.println(res.getString(3));
            System.out.println(res.getString(4));
        }

        res.close();
        st.close();
    }

    @Override
    public void singlesBeforeThanksGiving() throws SQLException {
        DbConnection dbConnection = new DbConnection();

        Statement st = dbConnection.getC().createStatement();
        ResultSet res = st.executeQuery("select * from songs where type = 'single' and release_date < '1965-11-25' ");

        while(res.next()){
            System.out.print(res.getInt(1) + " ");
            System.out.print(res.getString(2) + " ");
            System.out.print(res.getString(3) + " ");
            System.out.println(res.getString(4));
        }

        res.close();
        st.close();
    }

    @Override
    public void totalCountBySinglesLpEp() throws SQLException {
        DbConnection dbConnection = new DbConnection();
        Statement st = dbConnection.getC().createStatement();

        ResultSet res = st.executeQuery("select type, count(*) as total_count from songs where type in ('Single', 'EP' , 'LP') group by type; ");

        while(res.next()){
            System.out.print(res.getString(1) + " ");
            System.out.println(res.getInt(2) + " ");

        }

        res.close();
        st.close();

    }
}
